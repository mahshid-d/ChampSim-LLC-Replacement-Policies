# پروژه دوم معماری کامپیوتر: سیاست‌های جایگزینی LLC در ChampSim

این پروژه یک ماتریس اصلی شامل ۸ سیاست و ۴ Trace، معادل ۳۲ اجرا، و یک ماتریس تکمیلی شامل ۴ سیاست دیگر و همان ۴ Trace، معادل ۱۶ اجرا، دارد. مجموعه نهایی شامل **۱۲ سیاست، ۴ Trace و ۴۸ خروجی معتبر** است.

## سیاست‌های ارزیابی‌شده

سیاست‌های پایه:

- `lru` — ماژول موجود ChampSim
- `fifo` — پیاده‌سازی پروژه
- `mru` — پیاده‌سازی پروژه
- `random` — ماژول موجود ChampSim

سیاست‌های پیشرفته ماتریس اصلی:

- `brrip` — پیاده‌سازی پروژه
- `bip` — پیاده‌سازی پروژه
- `dip` — پیاده‌سازی پروژه
- `tree_plru` — پیاده‌سازی پروژه

سیاست‌های تکمیلی:

- `srrip` — ماژول موجود ChampSim
- `drrip` — ماژول موجود ChampSim
- `ship` — ماژول موجود ChampSim
- `ship_brrip` — سیاست ترکیبی پیشنهادی و پیاده‌سازی پروژه

پیاده‌سازی `lfu` نیز در مخزن وجود دارد، اما در ماتریس نهایی ۴۸تایی ارزیابی نشده است.

## Traceهای نهایی

- `464.h264ref-64B.champsimtrace.xz`
- `434.zeusmp-10B.champsimtrace.xz`
- `429.mcf-217B.champsimtrace.xz`
- `470.lbm-1274B.champsimtrace.xz`

مسیرهای محیط اجرای اصلی در `traces/manifest_final.csv` و الگوی قابل‌حمل در `traces/manifest.example.csv` ثبت شده‌اند. منبع و MD5ها در `traces/TRACE_SOURCES.md` قرار دارند.

## تنظیمات آزمایش

- Warmup: `1,000,000` دستور
- Simulation: `5,000,000` دستور
- LLC: دو MiB، `2048` مجموعه، `16-way` و بلوک 64 بایت
- Prefetcher: خاموش در همه سطوح
- سیاست سطوح غیر LLC: LRU
- ChampSim commit: `51588e1d6f97875fe8de1a3621d28668bff83fcf`

## اجرای کامل و افزایشی

پس از اصلاح مسیر Traceها در Manifest:

```bash
make run CHAMPSIM_ROOT="$PWD/ChampSim" PYTHON="$PWD/.venv/bin/python"
```

یا مستقیماً:

```bash
PYTHON="$PWD/.venv/bin/python" \
  bash scripts/run_all.sh "$PWD/ChampSim" traces/manifest_final.csv
```

گزینه `--resume` در Pipeline فعال است و خروجی‌های کامل و قابل Parse را دوباره اجرا نمی‌کند.

## اعتبارسنجی

```bash
python3 scripts/validate_results.py --require-bonus
```

خروجی صحیح:

```text
Expected policies: 12
Expected combinations: 48
Detailed rows: 48
Raw output files: 48
Summary rows: 12
BONUS VALIDATION PASSED
Raw outputs, CSV metrics, speedups, DRAM estimates, and summary are mutually consistent.
```

## خروجی‌ها

- خروجی خام: `results/final/raw/` — تعداد ۴۸ فایل
- جدول تفصیلی: `results/final/tables/detailed_results.csv`
- خلاصه سیاست‌ها: `results/final/tables/summary_by_policy.csv`
- شش نمودار اصلی و تکمیلی: `results/final/figures/`
- اطلاعات محیط: `results/final/environment.txt`
- گزارش Preflight: `results/final/NONREPORT_PREFLIGHT.txt`

## نتایج کلیدی

- بهترین میانگین هندسی Speedup: `BIP ≈ 1.0357`
- رتبه دوم: `SRRIP ≈ 1.0344`
- سیاست پیشنهادی `SHiP-BRRIP ≈ 1.0203`
- بهترین نتیجه روی `lbm_1274B`: `SRRIP ≈ 1.1061×`
- بهترین نتیجه روی `mcf_217B`: `BIP ≈ 1.0530×`
- `h264ref_64B` و `zeusmp_10B` دارای فعالیت واقعی LLC هستند، ولی در پنجره بررسی‌شده نسبت به Replacement Policy حساسیت IPC کمی نشان می‌دهند.

## بخش‌های امتیازی و تکمیلی

موارد امتیازی اصلی قابل ادعا:

1. طراحی و پیاده‌سازی سیاست ترکیبی جدید `SHiP-BRRIP`
2. خط لوله اجرای خودکار، افزایشی و بازتولیدپذیر

تحلیل‌های تکمیلی:

- مقایسه SHiP با SRRIP و DRRIP با استفاده از پیاده‌سازی‌های موجود ChampSim
- تحلیل پهنای باند DRAM با استفاده از شمارنده‌های RQ/WQ خروجی شبیه‌ساز

نباید ادعا شود که SHiP توسط گروه پیاده‌سازی شده است. همچنین پهنای باند یک تخمین بر اساس تعداد درخواست‌ها و فرض انتقال بلوک 64 بایتی است و سربار پروتکل را شامل نمی‌شود.

## محدودیت‌ها

- پنجره اصلی شبیه‌سازی 5M دستور است و ممکن است همه فازهای بلندمدت را پوشش ندهد.
- BIP، BRRIP و بخش BRRIP سیاست ترکیبی، احتمال `1/32` را با الگوی دوره‌ای deterministic تقریب می‌زنند.
- برای Random فقط یک اجرای نهایی انجام شده و تحلیل چند Seed انجام نشده است.
- سیاست ترکیبی بهترین سیاست کل مجموعه نیست؛ نتیجه آن باید به‌عنوان بهبود نسبت به LRU و برخی مراجع، نه برتری مطلق، گزارش شود.

## بازتولید روی سیستم دیگر

مسیرهای `manifest.csv` و `manifest_final.csv` نسبی هستند. برای اجرای مجدد،
چهار فایل Trace باید در پوشه `traces/trace_files/` قرار گیرند. نام فایل‌ها،
منبع و MD5 در `traces/TRACE_SOURCES.md` ثبت شده است.

محتوای submodule مربوط به `vcpkg` و کتابخانه‌های شخص ثالث داخل ZIP تحویل
قرار داده نشده است. برای Build کامل از صفر، ChampSim باید در Commit ثبت‌شده
با `--recurse-submodules` دریافت شود و سپس Policyهای پروژه با
`scripts/install_policies.py` نصب شوند. دستورهای دقیق در
`CHAMPSIM_REPRODUCE.md` آمده‌اند.

خروجی‌های خام بدون تغییر نگهداری شده‌اند تا سابقه واقعی اجرای آزمایش‌ها حفظ
شود؛ بنابراین ممکن است خط فرمان ثبت‌شده در آن‌ها مسیر ماشین اصلی را نشان دهد.
این مسیرها جزو داده‌های محاسباتی نیستند و Manifest قابل‌حمل برای بازتولید
جداگانه ارائه شده است.
