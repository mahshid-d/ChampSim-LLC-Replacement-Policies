#!/usr/bin/env bash
set -euo pipefail

PROJECT2_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SUBMISSION_DIR="$(dirname "$PROJECT2_DIR")"
SUBMISSION_NAME="$(basename "$SUBMISSION_DIR")"
OUTPUT="${1:-$HOME/Desktop/${SUBMISSION_NAME}.zip}"

[[ -s "$PROJECT2_DIR/report/report.pdf" ]] || {
  echo "ERROR: report/report.pdf is missing" >&2
  exit 1
}
[[ -s "$PROJECT2_DIR/report/report.tex" ]] || {
  echo "ERROR: report/report.tex is missing" >&2
  exit 1
}

raw_count="$(find "$PROJECT2_DIR/results/final/raw" -type f -name '*.txt' | wc -l | tr -d ' ')"
row_count="$(tail -n +2 "$PROJECT2_DIR/results/final/tables/detailed_results.csv" | wc -l | tr -d ' ')"
figure_count="$(find "$PROJECT2_DIR/results/final/figures" -maxdepth 1 -type f -name '*.png' | wc -l | tr -d ' ')"

[[ "$raw_count" == "48" ]] || { echo "ERROR: expected 48 raw outputs, found $raw_count"; exit 1; }
[[ "$row_count" == "48" ]] || { echo "ERROR: expected 48 rows, found $row_count"; exit 1; }
[[ "$figure_count" -ge 6 ]] || { echo "ERROR: expected at least 6 figures, found $figure_count"; exit 1; }

find "$SUBMISSION_DIR" -type d -name '__MACOSX' -prune -exec rm -rf {} +
find "$SUBMISSION_DIR" -type f -name '.DS_Store' -delete
find "$SUBMISSION_DIR" -type f -name '._*' -delete
find "$SUBMISSION_DIR" -type d -name '__pycache__' -prune -exec rm -rf {} +
find "$SUBMISSION_DIR" -type f -name '*.pyc' -delete
rm -rf "$PROJECT2_DIR/tests/build"

rm -f "$OUTPUT"
cd "$(dirname "$SUBMISSION_DIR")"
zip -qr "$OUTPUT" "$SUBMISSION_NAME" \
  -x '*/.DS_Store' \
  -x '*/__MACOSX/*' \
  -x '*/._*' \
  -x '*/__pycache__/*' \
  -x '*/tests/build/*' \
  -x '*/.venv/*' \
  -x '*/delivery_fix_backup_*/*'

unzip -t "$OUTPUT" >/dev/null

echo "FINAL ZIP CREATED: $OUTPUT"
echo "Raw outputs: $raw_count"
echo "Detailed rows: $row_count"
echo "Figures: $figure_count"
