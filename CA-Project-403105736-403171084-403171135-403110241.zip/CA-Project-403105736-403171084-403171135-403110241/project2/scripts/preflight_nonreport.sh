#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"

if [[ -n "${PYTHON:-}" ]]; then
  PY="$PYTHON"
elif [[ -x "$PROJECT_ROOT/.venv/bin/python" ]]; then
  PY="$PROJECT_ROOT/.venv/bin/python"
else
  PY="$(command -v python3)"
fi

errors=()

require_file() {
  [[ -s "$1" ]] || errors+=("Missing or empty: $1")
}

require_file "traces/manifest_final.csv"
require_file "traces/manifest.example.csv"
require_file "traces/TRACE_SOURCES.md"
require_file "configs/base_config.json"
require_file "configs/policies.json"
require_file "scripts/run_all.sh"
require_file "scripts/validate_results.py"
require_file "results/final/tables/detailed_results.csv"
require_file "results/final/tables/summary_by_policy.csv"
require_file "results/final/VALIDATION_FINAL.txt"
require_file "results/final/environment.txt"

raw_count="$(find results/final/raw -name '*.txt' -type f 2>/dev/null | wc -l | tr -d ' ')"
[[ "$raw_count" == "48" ]] || errors+=("Raw outputs: expected 48, found $raw_count")

csv_count="$(tail -n +2 results/final/tables/detailed_results.csv 2>/dev/null | wc -l | tr -d ' ')"
[[ "$csv_count" == "48" ]] || errors+=("Detailed CSV rows: expected 48, found $csv_count")

figure_count="$(find results/final/figures -maxdepth 1 -name '*.png' -type f 2>/dev/null | wc -l | tr -d ' ')"
[[ "$figure_count" -ge 6 ]] || errors+=("Figures: expected at least 6, found $figure_count")

for fig in \
  01_llc_miss_rate.png \
  02_ipc.png \
  03_speedup_vs_lru.png \
  04_bonus_ship_vs_rrip_ipc.png \
  05_bonus_memory_bandwidth_proxy.png \
  06_bonus_ship_brrip_speedup.png
do
  require_file "results/final/figures/$fig"
done

"$PY" - <<'PY' || exit 11
import csv
from pathlib import Path

expected_policies = {
    "lru", "fifo", "mru", "random", "brrip", "bip",
    "dip", "tree_plru", "srrip", "drrip", "ship", "ship_brrip",
}
expected_traces = {"h264ref_64B", "zeusmp_10B", "mcf_217B", "lbm_1274B"}

rows = list(csv.DictReader(Path("results/final/tables/detailed_results.csv").open()))
policies = {r["policy"] for r in rows}
traces = {r["trace"] for r in rows}
pairs = {(r["policy"], r["trace"]) for r in rows}

assert policies == expected_policies, (policies, expected_policies)
assert traces == expected_traces, (traces, expected_traces)
assert len(pairs) == 48
assert len(rows) == 48
print("Matrix check passed: 12 policies × 4 traces = 48")
PY

if grep -qE 'calculix_104B|gcc_48B' \
  traces/manifest_final.csv \
  results/final/environment.txt \
  results/final/tables/detailed_results.csv \
  results/final/tables/summary_by_policy.csv 2>/dev/null
then
  errors+=("Old trace names remain in final non-report files")
fi

if [[ ! -f ChampSim/config.sh ]]; then
  errors+=("Embedded ChampSim snapshot is missing")
fi

if ! grep -q 'Warmup instructions: 1000000' results/final/environment.txt; then
  errors+=("environment.txt has the wrong warmup count")
fi
if ! grep -q 'Simulation instructions: 5000000' results/final/environment.txt; then
  errors+=("environment.txt has the wrong simulation count")
fi
if ! grep -q 'Total runs: 48' results/final/environment.txt; then
  errors+=("environment.txt has the wrong run count")
fi

validation_output="$("$PY" scripts/validate_results.py --require-bonus 2>&1)" || {
  printf '%s\n' "$validation_output"
  errors+=("validate_results.py failed")
}
printf '%s\n' "$validation_output"

if ! printf '%s\n' "$validation_output" | grep -q 'BONUS VALIDATION PASSED'; then
  errors+=("BONUS VALIDATION PASSED was not reported")
fi

if ((${#errors[@]})); then
  echo
  echo "NON-REPORT PREFLIGHT FAILED"
  printf ' - %s\n' "${errors[@]}"
  exit 1
fi

echo
echo "NON-REPORT PREFLIGHT PASSED"
echo "Code, configs, scripts, traces, 48 outputs, tables, validation and figures are consistent."
