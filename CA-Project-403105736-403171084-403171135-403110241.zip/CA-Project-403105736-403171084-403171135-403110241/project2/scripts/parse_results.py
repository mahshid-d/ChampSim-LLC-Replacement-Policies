#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import re
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any

from common import DEFAULT_BASE_CONFIG, DEFAULT_MANIFEST, PROJECT_ROOT, load_traces

NUMBER = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?"
IPC_LINE_RE = re.compile(
    rf"CPU\s+\d+\s+(?:cumulative\s+)?IPC\s*:\s*(?P<ipc>{NUMBER})"
    rf"(?:[^\n]*?instructions\s*:\s*(?P<instructions>\d+)[^\n]*?cycles\s*:\s*(?P<cycles>\d+))?",
    re.IGNORECASE,
)
INSTRUCTIONS_RE = re.compile(r"instructions\s*:\s*(\d+)", re.IGNORECASE)
CYCLES_RE = re.compile(r"cycles\s*:\s*(\d+)", re.IGNORECASE)
LLC_RE = re.compile(
    r"LLC\s+TOTAL\s+ACCESS\s*:\s*(?P<access>\d+)\s+HIT\s*:\s*(?P<hit>\d+)\s+MISS\s*:\s*(?P<miss>\d+)",
    re.IGNORECASE,
)
DRAM_RQ_RE = re.compile(
    r"Channel\s+\d+\s+RQ\s+ROW_BUFFER_HIT\s*:\s*(?P<hit>\d+)\s*\n\s*ROW_BUFFER_MISS\s*:\s*(?P<miss>\d+)",
    re.IGNORECASE,
)
DRAM_WQ_RE = re.compile(
    r"Channel\s+\d+\s+WQ\s+ROW_BUFFER_HIT\s*:\s*(?P<hit>\d+)\s*\n\s*ROW_BUFFER_MISS\s*:\s*(?P<miss>\d+)",
    re.IGNORECASE,
)
COMPLETION_MARKER = "ChampSim completed all CPUs"


def last_match(pattern: re.Pattern[str], text: str) -> re.Match[str] | None:
    matches = list(pattern.finditer(text))
    return matches[-1] if matches else None


def parse_output(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8", errors="replace")
    if COMPLETION_MARKER not in text:
        raise ValueError("ChampSim completion marker not found")

    ipc_match = last_match(IPC_LINE_RE, text)
    llc_match = last_match(LLC_RE, text)
    dram_rq_match = last_match(DRAM_RQ_RE, text)
    dram_wq_match = last_match(DRAM_WQ_RE, text)
    if ipc_match is None:
        raise ValueError("IPC line not found")
    if llc_match is None:
        raise ValueError("LLC TOTAL ACCESS/HIT/MISS line not found")
    if dram_rq_match is None or dram_wq_match is None:
        raise ValueError("DRAM RQ/WQ statistics not found")

    instructions_value = ipc_match.group("instructions")
    cycles_value = ipc_match.group("cycles")
    if instructions_value is None:
        match = last_match(INSTRUCTIONS_RE, text)
        instructions_value = match.group(1) if match else None
    if cycles_value is None:
        match = last_match(CYCLES_RE, text)
        cycles_value = match.group(1) if match else None
    if instructions_value is None or cycles_value is None:
        raise ValueError("instruction or cycle count not found")

    reported_ipc = float(ipc_match.group("ipc"))
    instructions = int(instructions_value)
    cycles = int(cycles_value)
    accesses = int(llc_match.group("access"))
    hits = int(llc_match.group("hit"))
    misses = int(llc_match.group("miss"))
    dram_rq_hits = int(dram_rq_match.group("hit"))
    dram_rq_misses = int(dram_rq_match.group("miss"))
    dram_wq_hits = int(dram_wq_match.group("hit"))
    dram_wq_misses = int(dram_wq_match.group("miss"))

    if accesses <= 0 or instructions <= 0 or cycles <= 0:
        raise ValueError("non-positive access, instruction, or cycle count")

    return {
        "ipc": reported_ipc,
        "instructions": instructions,
        "cycles": cycles,
        "llc_accesses": accesses,
        "llc_hits": hits,
        "llc_misses": misses,
        "hit_rate": hits / accesses,
        "miss_rate": misses / accesses,
        "mpki": misses * 1000.0 / instructions,
        "access_consistent": hits + misses == accesses,
        "dram_rq_row_hits": dram_rq_hits,
        "dram_rq_row_misses": dram_rq_misses,
        "dram_wq_row_hits": dram_wq_hits,
        "dram_wq_row_misses": dram_wq_misses,
        "dram_read_requests": dram_rq_hits + dram_rq_misses,
        "dram_write_requests": dram_wq_hits + dram_wq_misses,
        "dram_total_requests": dram_rq_hits + dram_rq_misses + dram_wq_hits + dram_wq_misses,
    }


def load_arch_parameters(path: Path) -> tuple[int, float]:
    with path.open("r", encoding="utf-8") as handle:
        config = json.load(handle)
    block_size = int(config.get("block_size", 64))
    cpus = config.get("ooo_cpu") or [{}]
    frequency_mhz = float(cpus[0].get("frequency", 4000))
    if block_size <= 0 or frequency_mhz <= 0:
        raise ValueError("block_size and CPU frequency must be positive")
    return block_size, frequency_mhz


def geometric_mean(values: list[float]) -> float:
    positive = [value for value in values if value > 0 and math.isfinite(value)]
    if not positive:
        return math.nan
    return math.exp(sum(math.log(value) for value in positive) / len(positive))


def write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def portable_output_path(path: Path) -> str:
    try:
        return str(path.resolve().relative_to(PROJECT_ROOT.resolve()))
    except ValueError:
        return str(path)


def main() -> int:
    parser = argparse.ArgumentParser(description="Parse ChampSim output and compute core and DRAM-derived metrics.")
    parser.add_argument("--raw-dir", type=Path, default=Path("results/raw"))
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--output-dir", type=Path, default=Path("results/tables"))
    parser.add_argument("--base-config", type=Path, default=DEFAULT_BASE_CONFIG)
    parser.add_argument("--baseline", default="lru")
    args = parser.parse_args()

    raw_dir = args.raw_dir.resolve()
    output_dir = args.output_dir.resolve()
    trace_classes = {trace.name: trace.trace_class for trace in load_traces(args.manifest)}
    block_size, frequency_mhz = load_arch_parameters(args.base_config.resolve())

    rows: list[dict[str, Any]] = []
    errors: list[str] = []
    for output in sorted(raw_dir.glob("*/*.txt")):
        policy = output.parent.name
        trace = output.stem
        try:
            metrics = parse_output(output)
        except ValueError as exc:
            errors.append(f"{output}: {exc}")
            continue

        llc_read_bytes_lower_bound = metrics["llc_misses"] * block_size
        llc_read_bandwidth_proxy = (
            llc_read_bytes_lower_bound * frequency_mhz * 1_000_000.0
            / metrics["cycles"] / 1_000_000_000.0
        )

        dram_read_bytes = metrics["dram_read_requests"] * block_size
        dram_write_bytes = metrics["dram_write_requests"] * block_size
        dram_total_bytes = metrics["dram_total_requests"] * block_size
        seconds = metrics["cycles"] / (frequency_mhz * 1_000_000.0)

        rows.append(
            {
                "policy": policy,
                "trace": trace,
                "class": trace_classes.get(trace, ""),
                **metrics,
                "speedup_vs_lru": math.nan,
                "block_size_bytes": block_size,
                "cpu_frequency_mhz": frequency_mhz,
                "llc_read_traffic_bytes_lower_bound": llc_read_bytes_lower_bound,
                "estimated_read_bandwidth_gbps": llc_read_bandwidth_proxy,
                "dram_read_traffic_bytes_estimate": dram_read_bytes,
                "dram_write_traffic_bytes_estimate": dram_write_bytes,
                "dram_total_traffic_bytes_estimate": dram_total_bytes,
                "estimated_dram_read_bandwidth_gbps": dram_read_bytes / seconds / 1_000_000_000.0,
                "estimated_dram_write_bandwidth_gbps": dram_write_bytes / seconds / 1_000_000_000.0,
                "estimated_dram_total_bandwidth_gbps": dram_total_bytes / seconds / 1_000_000_000.0,
                "output_file": portable_output_path(output),
            }
        )

    if errors:
        print("Parsing errors:")
        for error in errors:
            print("  " + error)
    if not rows:
        raise SystemExit("No parseable outputs found")

    baseline_ipc = {row["trace"]: row["ipc"] for row in rows if row["policy"] == args.baseline}
    missing_baseline = sorted({row["trace"] for row in rows} - set(baseline_ipc))
    if missing_baseline:
        raise SystemExit(f"Missing {args.baseline} results for traces: {', '.join(missing_baseline)}")

    for row in rows:
        row["speedup_vs_lru"] = row["ipc"] / baseline_ipc[row["trace"]]

    rows.sort(key=lambda item: (item["trace"], item["policy"]))
    detailed_fields = [
        "policy", "trace", "class", "ipc", "instructions", "cycles",
        "llc_accesses", "llc_hits", "llc_misses", "hit_rate", "miss_rate", "mpki",
        "speedup_vs_lru", "block_size_bytes", "cpu_frequency_mhz",
        "llc_read_traffic_bytes_lower_bound", "estimated_read_bandwidth_gbps",
        "dram_rq_row_hits", "dram_rq_row_misses", "dram_wq_row_hits", "dram_wq_row_misses",
        "dram_read_requests", "dram_write_requests", "dram_total_requests",
        "dram_read_traffic_bytes_estimate", "dram_write_traffic_bytes_estimate",
        "dram_total_traffic_bytes_estimate", "estimated_dram_read_bandwidth_gbps",
        "estimated_dram_write_bandwidth_gbps", "estimated_dram_total_bandwidth_gbps",
        "access_consistent", "output_file",
    ]
    write_csv(output_dir / "detailed_results.csv", detailed_fields, rows)

    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[row["policy"]].append(row)

    summary_rows: list[dict[str, Any]] = []
    for policy, policy_rows in grouped.items():
        summary_rows.append(
            {
                "policy": policy,
                "trace_count": len(policy_rows),
                "mean_ipc": statistics.fmean(row["ipc"] for row in policy_rows),
                "mean_miss_rate": statistics.fmean(row["miss_rate"] for row in policy_rows),
                "mean_mpki": statistics.fmean(row["mpki"] for row in policy_rows),
                "mean_estimated_read_bandwidth_gbps": statistics.fmean(row["estimated_read_bandwidth_gbps"] for row in policy_rows),
                "mean_estimated_dram_read_bandwidth_gbps": statistics.fmean(row["estimated_dram_read_bandwidth_gbps"] for row in policy_rows),
                "mean_estimated_dram_write_bandwidth_gbps": statistics.fmean(row["estimated_dram_write_bandwidth_gbps"] for row in policy_rows),
                "mean_estimated_dram_total_bandwidth_gbps": statistics.fmean(row["estimated_dram_total_bandwidth_gbps"] for row in policy_rows),
                "geomean_speedup_vs_lru": geometric_mean([row["speedup_vs_lru"] for row in policy_rows]),
                "min_speedup_vs_lru": min(row["speedup_vs_lru"] for row in policy_rows),
                "max_speedup_vs_lru": max(row["speedup_vs_lru"] for row in policy_rows),
            }
        )
    summary_rows.sort(key=lambda item: item["geomean_speedup_vs_lru"], reverse=True)
    summary_fields = [
        "policy", "trace_count", "mean_ipc", "mean_miss_rate", "mean_mpki",
        "mean_estimated_read_bandwidth_gbps", "mean_estimated_dram_read_bandwidth_gbps",
        "mean_estimated_dram_write_bandwidth_gbps", "mean_estimated_dram_total_bandwidth_gbps",
        "geomean_speedup_vs_lru", "min_speedup_vs_lru", "max_speedup_vs_lru",
    ]
    write_csv(output_dir / "summary_by_policy.csv", summary_fields, summary_rows)

    print(output_dir / "detailed_results.csv")
    print(output_dir / "summary_by_policy.csv")
    return 2 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
