#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUTPUT_ZIP="${1:-$PROJECT_ROOT/../project2_bonus_submission.zip}"
PYTHON="${PYTHON:-python3}"

cd "$PROJECT_ROOT"

"$PYTHON" scripts/parse_results.py \
  --raw-dir results/final/raw \
  --manifest traces/manifest_final.csv \
  --base-config configs/base_config.json \
  --output-dir results/final/tables \
  --baseline lru

"$PYTHON" scripts/validate_results.py --require-bonus

"$PYTHON" scripts/plot_results.py \
  --input results/final/tables/detailed_results.csv \
  --output-dir results/final/figures \
  --policy-file configs/policies.json

"$PYTHON" scripts/generate_bonus_appendix.py \
  --detailed results/final/tables/detailed_results.csv \
  --summary results/final/tables/summary_by_policy.csv \
  --output report/bonus_appendix.tex

cp results/final/tables/*.csv report/data/
cp results/final/figures/*.png report/figures/

if command -v latexmk >/dev/null 2>&1; then
  (cd report && latexmk -xelatex -interaction=nonstopmode -halt-on-error report.tex)
else
  echo "WARNING: latexmk not found; report.pdf was not rebuilt." >&2
fi

find . -type d -name '__pycache__' -prune -exec rm -rf {} +
rm -rf tests/build ChampSim/.csconfig ChampSim/bin
rm -f report/*.aux report/*.log report/*.toc report/*.out report/*.bcf \
      report/*.run.xml report/*.xdv report/*.bbl report/*.blg report/*.fls \
      report/*.fdb_latexmk

rm -f "$OUTPUT_ZIP"
(
  cd "$PROJECT_ROOT/.."
  zip -qr "$OUTPUT_ZIP" "$(basename "$PROJECT_ROOT")" \
    -x '*/.DS_Store' \
    -x '*/__MACOSX/*' \
    -x '*/._*' \
    -x '*/__pycache__/*' \
    -x '*/tests/build/*' \
    -x '*/ChampSim/.csconfig/*' \
    -x '*/ChampSim/bin/*' \
    -x '*/.venv/*' \
    -x '*/delivery_fix_backup_*/*'
)

echo "Created: $OUTPUT_ZIP"
