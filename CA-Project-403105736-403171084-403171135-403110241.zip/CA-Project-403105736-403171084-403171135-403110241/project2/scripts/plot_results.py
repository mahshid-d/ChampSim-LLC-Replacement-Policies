#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path

from common import DEFAULT_POLICY_FILE, all_policies


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def grouped_bar(rows: list[dict[str, str]], metric: str, ylabel: str, title: str, output: Path,
                policy_order: list[str]) -> None:
    try:
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise SystemExit("matplotlib is required: python3 -m pip install matplotlib") from exc

    by_trace: dict[str, dict[str, float]] = defaultdict(dict)
    for row in rows:
        by_trace[row["trace"]][row["policy"]] = float(row[metric])
    traces = list(by_trace)
    present_policies = [policy for policy in policy_order if any(policy in by_trace[trace] for trace in traces)]

    figure_width = max(10.0, 1.8 * len(traces))
    fig, ax = plt.subplots(figsize=(figure_width, 6.2))
    group_width = 0.84
    bar_width = group_width / max(1, len(present_policies))
    centers = list(range(len(traces)))
    for index, policy in enumerate(present_policies):
        offset = -group_width / 2 + bar_width / 2 + index * bar_width
        values = [by_trace[trace].get(policy, float("nan")) for trace in traces]
        ax.bar([center + offset for center in centers], values, width=bar_width, label=policy)

    ax.set_xticks(centers)
    ax.set_xticklabels(traces, rotation=20, ha="right")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(axis="y", alpha=0.25)
    ax.legend(ncol=min(4, max(1, len(present_policies))), bbox_to_anchor=(0.5, -0.20), loc="upper center")
    fig.tight_layout()
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=180, bbox_inches="tight")
    plt.close(fig)


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate required charts and conditional bonus charts.")
    parser.add_argument("--input", type=Path, default=Path("results/tables/detailed_results.csv"))
    parser.add_argument("--output-dir", type=Path, default=Path("results/figures"))
    parser.add_argument("--policy-file", type=Path, default=DEFAULT_POLICY_FILE)
    args = parser.parse_args()

    rows = read_rows(args.input.resolve())
    if not rows:
        raise SystemExit("Input CSV is empty")
    policy_order = all_policies(args.policy_file)
    output_dir = args.output_dir.resolve()

    grouped_bar(rows, "miss_rate", "LLC miss rate", "LLC miss rate by policy and trace",
                output_dir / "01_llc_miss_rate.png", policy_order)
    grouped_bar(rows, "ipc", "IPC", "IPC by policy and trace",
                output_dir / "02_ipc.png", policy_order)
    grouped_bar(rows, "speedup_vs_lru", "IPC(policy) / IPC(LRU)", "Performance relative to LRU",
                output_dir / "03_speedup_vs_lru.png", policy_order)

    present = {row["policy"] for row in rows}
    if {"srrip", "drrip", "ship"}.issubset(present):
        grouped_bar(rows, "ipc", "IPC", "Bonus: SHiP vs SRRIP and DRRIP",
                    output_dir / "04_bonus_ship_vs_rrip_ipc.png", ["srrip", "drrip", "ship"])

    if "estimated_dram_total_bandwidth_gbps" in rows[0]:
        grouped_bar(rows, "estimated_dram_total_bandwidth_gbps", "Estimated DRAM bandwidth (GB/s)",
                    "Bonus: DRAM request-derived total bandwidth estimate",
                    output_dir / "05_bonus_memory_bandwidth_proxy.png", policy_order)
    elif "estimated_read_bandwidth_gbps" in rows[0]:
        grouped_bar(rows, "estimated_read_bandwidth_gbps", "Estimated read bandwidth (GB/s)",
                    "Bonus: lower-bound off-chip read-bandwidth proxy",
                    output_dir / "05_bonus_memory_bandwidth_proxy.png", policy_order)

    if "ship_brrip" in present:
        grouped_bar(rows, "speedup_vs_lru", "IPC(policy) / IPC(LRU)",
                    "Bonus: SHiP-BRRIP hybrid relative to LRU",
                    output_dir / "06_bonus_ship_brrip_speedup.png",
                    ["lru", "srrip", "drrip", "ship", "ship_brrip"])

    for path in sorted(output_dir.glob("*.png")):
        print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
