#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from common import DEFAULT_BASE_CONFIG, DEFAULT_POLICY_FILE, parse_policy_selection, write_policy_config


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate one ChampSim JSON configuration per replacement policy.")
    parser.add_argument("--base-config", type=Path, default=DEFAULT_BASE_CONFIG)
    parser.add_argument("--policy-file", type=Path, default=DEFAULT_POLICY_FILE)
    parser.add_argument("--policies", help="Comma-separated subset. Default: all policies.")
    parser.add_argument("--output-dir", type=Path, default=Path("generated_configs"))
    args = parser.parse_args()

    policies = parse_policy_selection(args.policies, args.policy_file)
    output_dir = args.output_dir.resolve()
    for policy in policies:
        path = output_dir / f"{policy}.json"
        write_policy_config(args.base_config.resolve(), path, policy)
        print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
