#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path
from typing import Iterable

from common import markdown_table


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def fmt(value: float, digits: int = 4) -> str:
    if not math.isfinite(value):
        return "—"
    return f"{value:.{digits}f}"


def pearson(xs: list[float], ys: list[float]) -> float:
    if len(xs) != len(ys) or len(xs) < 2:
        return math.nan
    mx = sum(xs) / len(xs)
    my = sum(ys) / len(ys)
    numerator = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    dx = math.sqrt(sum((x - mx) ** 2 for x in xs))
    dy = math.sqrt(sum((y - my) ** 2 for y in ys))
    return numerator / (dx * dy) if dx and dy else math.nan


def join_fa(items: Iterable[str]) -> str:
    values = list(items)
    return "، ".join(values) if values else "هیچ‌کدام"


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate a Persian project report from measured ChampSim results.")
    parser.add_argument("--detailed", type=Path, default=Path("results/tables/detailed_results.csv"))
    parser.add_argument("--summary", type=Path, default=Path("results/tables/summary_by_policy.csv"))
    parser.add_argument("--output", type=Path, default=Path("report/report_generated_fa.md"))
    parser.add_argument("--warmup", type=int, default=50_000_000)
    parser.add_argument("--simulation", type=int, default=200_000_000)
    args = parser.parse_args()

    detailed = read_csv(args.detailed.resolve())
    summary = read_csv(args.summary.resolve())
    if not detailed or not summary:
        raise SystemExit("Result tables are empty")

    by_trace: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in detailed:
        by_trace[row["trace"]].append(row)

    best_by_trace: dict[str, dict[str, str]] = {
        trace: max(rows, key=lambda row: float(row["ipc"])) for trace, rows in by_trace.items()
    }
    overall_best = max(summary, key=lambda row: float(row["geomean_speedup_vs_lru"]))
    universal = [policy for policy in {row["policy"] for row in detailed}
                 if all(best_by_trace[trace]["policy"] == policy for trace in by_trace)]
    advanced = {"srrip", "brrip", "bip", "dip", "drrip", "tree_plru", "lfu", "ship"}
    simple = {"lru", "fifo", "mru", "random"}
    advanced_wins = [trace for trace, winner in best_by_trace.items() if winner["policy"] in advanced]

    simple_adequate: list[str] = []
    for trace, rows in by_trace.items():
        best_ipc = max(float(row["ipc"]) for row in rows)
        best_simple = max((float(row["ipc"]) for row in rows if row["policy"] in simple), default=0.0)
        if best_ipc > 0 and best_simple / best_ipc >= 0.99:
            simple_adequate.append(trace)

    correlation = pearson(
        [float(row["miss_rate"]) for row in detailed],
        [float(row["ipc"]) for row in detailed],
    )

    result_table_rows = []
    for trace, rows in by_trace.items():
        for row in sorted(rows, key=lambda item: float(item["ipc"]), reverse=True):
            result_table_rows.append([
                trace,
                row["class"],
                row["policy"],
                fmt(float(row["ipc"]), 5),
                fmt(float(row["miss_rate"]) * 100, 3) + "%",
                fmt(float(row["mpki"]), 3),
                fmt(float(row["speedup_vs_lru"]), 4),
            ])

    summary_rows = [[
        row["policy"],
        fmt(float(row["mean_ipc"]), 5),
        fmt(float(row["mean_mpki"]), 3),
        fmt(float(row["mean_miss_rate"]) * 100, 3) + "%",
        fmt(float(row["geomean_speedup_vs_lru"]), 4),
        fmt(float(row["min_speedup_vs_lru"]), 4),
        fmt(float(row["max_speedup_vs_lru"]), 4),
    ] for row in summary]

    cost_rows = [
        ["LRU", "زمان آخرین استفاده/رتبه", "مقایسهٔ همهٔ راه‌ها", "زیاد؛ LRU دقیق در 16-way پرهزینه است"],
        ["FIFO", "ترتیب ورود یا اشاره‌گر صف", "انتخاب قدیمی‌ترین ورودی", "کم تا متوسط"],
        ["MRU", "زمان آخرین استفاده/رتبه", "انتخاب جدیدترین راه", "مشابه LRU"],
        ["Random", "بدون بیت خط؛ فقط LFSR/PRNG", "ثابت", "بسیار کم"],
        ["SRRIP", "2 بیت RRPV برای هر خط", "جست‌وجوی RRPV=3 و aging", "کم"],
        ["BRRIP", "2 بیت/خط + شمارندهٔ 5 بیتی", "مشابه SRRIP", "کم"],
        ["BIP", "رتبهٔ LRU + شمارندهٔ throttle", "مشابه LRU", "متوسط تا زیاد"],
        ["DIP", "متادیتای LRU + PSEL ده‌بیتی + leader-set", "LRU/BIP و set-dueling", "متوسط تا زیاد"],
        ["DRRIP", "2 بیت/خط + PSEL ده‌بیتی + leader-set", "RRIP و set-dueling", "کم تا متوسط"],
        ["Tree-PLRU", "W-1 بیت برای هر مجموعه؛ 15 بیت در 16-way", "O(log W)", "بسیار مناسب سخت‌افزار"],
        ["LFU", "شمارندهٔ 8 بیتی/خط + زمان رفع تساوی", "کمینهٔ فراوانی و aging", "زیاد"],
        ["SHiP", "RRPV + signature/sampler + SHCT", "پیش‌بینی reuse بر اساس PC", "متوسط تا زیاد"],
    ]

    report = f"""# گزارش پروژهٔ تحلیل سیاست‌های جایگزینی LLC در ChampSim

## ۱. خلاصهٔ اجرایی

این پروژه چهار سیاست پایهٔ `LRU`، `FIFO`، `MRU` و `Random` و هشت سیاست پیشرفتهٔ `SRRIP`، `BRRIP`، `BIP`، `DIP`، `DRRIP`، `Tree-PLRU`، `LFU` و `SHiP` را روی حافظهٔ نهان سطح آخر مقایسه می‌کند. معیار اصلی IPC است و معیارهای LLC شامل تعداد دسترسی، برخورد، عدم برخورد، نرخ عدم برخورد و MPKI نیز استخراج شده‌اند. مبنای نرمال‌سازی کارایی رابطهٔ زیر است:

```text
Speedup = IPC(policy) / IPC(LRU)
```

بر اساس میانگین هندسی speedup، بهترین سیاست این مجموعه **{overall_best['policy']}** با مقدار **{fmt(float(overall_best['geomean_speedup_vs_lru']), 4)}** بوده است. این نتیجه فقط برای ردپاها و پیکربندی همین آزمایش معتبر است.

## ۲. پیکربندی آزمایش

تمام متغیرها به‌جز سیاست جایگزینی LLC ثابت نگه داشته شدند:

- اندازهٔ بلوک: 64 بایت
- LLC: تعداد مجموعه 2048، هم‌انجمنی 16، ظرفیت کل 2 MiB
- پیش‌واکشی L1I/L1D/L2C/LLC: غیرفعال
- سیاست سطوح غیر از LLC: LRU
- تعداد هسته: 1
- دستورهای گرم‌سازی: {args.warmup:,}
- دستورهای شبیه‌سازی: {args.simulation:,}

این تثبیت مانع از آن می‌شود که تغییر هم‌زمان اندازهٔ کش، هم‌انجمنی، پیش‌واکشی یا طول شبیه‌سازی با اثر سیاست جایگزینی مخلوط شود.

## ۳. پیاده‌سازی سیاست‌ها

### ۳.۱ سیاست‌های پایه

**LRU:** برای هر خط، ترتیب یا زمان آخرین استفاده نگه‌داری می‌شود. قربانی خطی است که قدیمی‌ترین استفاده را دارد. در برخورد و پرشدن، خط به MRU منتقل می‌شود.

**FIFO:** تنها زمان ورود خط نگه‌داری می‌شود. برخورد هیچ تغییری در وضعیت ایجاد نمی‌کند و قدیمی‌ترین خط واردشده قربانی است.

**MRU:** وضعیت مشابه LRU است، اما جدیدترین خط استفاده‌شده قربانی می‌شود. این سیاست برای الگوهایی که مراجعهٔ اخیر احتمالاً دیگر تکرار نمی‌شود می‌تواند مفید باشد، ولی برای locality زمانی معمولاً ضعیف است.

**Random:** قربانی با مولد شبه‌تصادفی انتخاب می‌شود. این سیاست متادیتای خط ندارد و مبنای کم‌هزینه‌ای برای مقایسه است.

### ۳.۲ سیاست‌های پیشرفته

**SRRIP:** برای هر خط یک RRPV دوبیتی در بازهٔ 0 تا 3 نگه می‌دارد. برخورد RRPV را صفر می‌کند و خط جدید با RRPV=2 وارد می‌شود. در نبود خط با RRPV=3، همهٔ مقادیر به‌صورت اشباعی پیر می‌شوند.

**BRRIP:** مشابه SRRIP است، اما بیشتر خطوط با RRPV=3 وارد می‌شوند و هر 32 ورود یک خط با RRPV=2 وارد می‌شود. این رفتار از آلودگی ناشی از داده‌های یک‌بارمصرف جلوگیری می‌کند.

**BIP:** ساختار LRU را حفظ می‌کند، ولی بیشتر خطوط جدید را در LRU و فقط هر 32 ورود یک خط را در MRU قرار می‌دهد. برخورد همچنان خط را به MRU ارتقا می‌دهد.

**DIP:** با مجموعه‌های رهبر، LRU و BIP را به رقابت می‌گذارد. شمارندهٔ اشباعی PSEL رفتار مجموعه‌های پیرو را تعیین می‌کند. miss در رهبر LRU رأی به BIP و miss در رهبر BIP رأی به LRU می‌دهد.

**DRRIP:** همان set-dueling را بین SRRIP و BRRIP اجرا می‌کند. متادیتای هر خط فقط RRPV دوبیتی است و PSEL انتخاب سیاست ورود را کنترل می‌کند.

**Tree-PLRU:** یک درخت دودویی با W-1 بیت برای هر مجموعه نگه می‌دارد. هر برخورد بیت‌های مسیر را طوری تغییر می‌دهد که زیر‌درخت مقابل به‌عنوان LRU تقریبی مشخص شود. انتخاب و به‌روزرسانی O(log W) است.

**LFU:** شمارندهٔ فراوانی 8 بیتی و زمان آخرین تماس برای رفع تساوی نگه می‌دارد. قربانی کم‌استفاده‌ترین خط است. هنگام اشباع شمارنده‌ها، aging سراسری با نصف‌کردن انجام می‌شود.

**SHiP:** از امضای PC، sampler و جدول SHCT برای پیش‌بینی reuse استفاده می‌کند و مقدار ورود RRPV را با تاریخچهٔ همان امضا تنظیم می‌کند.

در بستهٔ حاضر، `FIFO`، `MRU`، `BRRIP`، `BIP`، `DIP`، `Tree-PLRU` و `LFU` پیاده‌سازی شده‌اند. `LRU`، `Random`، `SRRIP`، `DRRIP` و `SHiP` از ماژول‌های نسخهٔ جاری ChampSim استفاده می‌شوند.

## ۴. نتایج تفصیلی

{markdown_table(['ردپا', 'کلاس', 'سیاست', 'IPC', 'LLC miss rate', 'MPKI', 'Speedup/LRU'], result_table_rows)}

## ۵. جمع‌بندی بر حسب سیاست

{markdown_table(['سیاست', 'میانگین IPC', 'میانگین MPKI', 'میانگین miss rate', 'GeoMean speedup', 'کمینه speedup', 'بیشینه speedup'], summary_rows)}

## ۶. تحلیل نتایج و پاسخ به پرسش‌های پروژه

### ۶.۱ کدام سیاست در میانگین همهٔ ردپاها بهترین است؟

سیاست **{overall_best['policy']}** بالاترین میانگین هندسی کارایی نسبت به LRU را دارد. استفاده از میانگین هندسی برای نسبت‌های کارایی مناسب‌تر از میانگین حسابی است، زیرا اثر مقیاس‌های متفاوت را کاهش می‌دهد.

### ۶.۲ آیا یک سیاست برای همهٔ ردپاها بهترین است؟

{('بله؛ سیاست ' + universal[0] + ' در همهٔ ردپاها بالاترین IPC را داشته است.' if universal else 'خیر. برندهٔ هر ردپا متفاوت است و یک سیاست غالب مطلق مشاهده نشد.')}

برندگان به تفکیک ردپا:

{markdown_table(['ردپا', 'کلاس', 'سیاست برنده', 'IPC', 'Speedup/LRU'], [[trace, winner['class'], winner['policy'], fmt(float(winner['ipc']), 5), fmt(float(winner['speedup_vs_lru']), 4)] for trace, winner in best_by_trace.items()])}

### ۶.۳ در کدام ردپاها سیاست‌های پیشرفته از LRU بهتر عمل کرده‌اند؟

ردپاهایی که برندهٔ آن‌ها یک سیاست پیشرفته بوده است: **{join_fa(advanced_wins)}**. برای نتیجه‌گیری دقیق‌تر باید علاوه بر برنده، مقدار speedup و کاهش MPKI نیز بررسی شود؛ اختلاف‌های بسیار کوچک ممکن است با تغییر طول شبیه‌سازی جابه‌جا شوند.

### ۶.۴ در کدام ردپاها سیاست ساده کافی بوده است؟

در ردپاهای **{join_fa(simple_adequate)}** بهترین سیاست ساده حداکثر یک درصد از بهترین سیاست کل فاصله داشته است. در این حالت هزینهٔ سخت‌افزاری کمتر می‌تواند از سود ناچیز سیاست پیچیده مهم‌تر باشد.

### ۶.۵ آیا کاهش miss rate همیشه IPC را افزایش داده است؟

ضریب هم‌بستگی پیرسون میان miss rate و IPC روی تمام نقاط آزمایش **{fmt(correlation, 4)}** است. هم‌بستگی منفی قوی به‌طور کلی انتظار می‌رود، اما کاهش miss rate الزاماً افزایش متناسب IPC ایجاد نمی‌کند؛ نوع miss، هم‌پوشانی missها، MLP، تأخیر حافظه، فشار صف‌ها و مسیر بحرانی اجرای دستورها تعیین می‌کنند که هر miss حذف‌شده چه مقدار زمان پردازنده را آزاد کند.

### ۶.۶ رفتار سیاست‌های سازگارشونده چگونه تفسیر می‌شود؟

`DIP` و `DRRIP` با leader-set و PSEL رفتار غالب را در زمان اجرا انتخاب می‌کنند، بنابراین در workloadهای دارای فاز یا ترکیب locality/streaming باید نسبت به سیاست ثابت پایدارتر باشند. `SHiP` تصمیم را به امضای PC وابسته می‌کند و می‌تواند داده‌های تولیدشده توسط دستورهای بدون reuse را زودتر حذف کند. اگر این سیاست‌ها در یک ردپا ضعیف باشند، دلایل محتمل شامل آموزش ناکافی، aliasing جدول امضا، فازهای کوتاه، یا عدم تطابق نمونه‌برداری با رفتار کل کش است.

## ۷. پیچیدگی و هزینهٔ تقریبی سخت‌افزاری

{markdown_table(['سیاست', 'متادیتا', 'منطق قربانی/به‌روزرسانی', 'ارزیابی هزینه'], cost_rows)}

اگر فقط کارایی مهم باشد، سیاست برتر تجربی این مجموعه انتخاب می‌شود. اگر سادگی سخت‌افزار نیز مهم باشد، `Tree-PLRU` یا `SRRIP/BRRIP` معمولاً نقطهٔ توازن مناسبی ارائه می‌کنند؛ تصمیم نهایی باید با speedup واقعی جدول بالا سنجیده شود، نه صرفاً شهرت سیاست.

## ۸. محدودیت‌ها و اعتبار آزمایش

1. نتایج به نسخهٔ ChampSim، ردپا، نقطهٔ شروع ردپا و طول ROI حساس‌اند.
2. یک اجرای قطعی برای سیاست‌های تصادفی کافی نیست؛ برای Random و سیاست‌های دارای sampling تصادفی بهتر است چند seed اجرا و فاصلهٔ اطمینان گزارش شود.
3. طبقه‌بندی temporal/spatial/streaming باید با رفتار اندازه‌گیری‌شده تأیید شود.
4. خروجی شبیه‌ساز مدل نرم‌افزاری است؛ زمان اجرای خود سیاست در شبیه‌ساز معادل تأخیر سخت‌افزاری نیست.
5. نتیجه‌گیری علت و معلولی باید با ثابت‌بودن همهٔ پارامترها و بررسی تکرارپذیری پشتیبانی شود.

## ۹. فایل‌های تحویلی

- پوشهٔ `replacement/`: سیاست‌های افزوده‌شده
- `configs/base_config.json`: پیکربندی پایهٔ ثابت
- `traces/manifest.csv`: فهرست ردپاها
- `scripts/run_experiments.py`: ساخت و اجرای ماتریس آزمایش
- `scripts/parse_results.py`: استخراج معیارها
- `scripts/plot_results.py`: تولید سه نمودار اجباری
- `results/raw/`: خروجی خام هر اجرای شبیه‌سازی
- `results/tables/`: جدول‌های CSV
- `results/figures/`: نمودارها
- این گزارش و تحلیل نهایی
"""

    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(report, encoding="utf-8")
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
