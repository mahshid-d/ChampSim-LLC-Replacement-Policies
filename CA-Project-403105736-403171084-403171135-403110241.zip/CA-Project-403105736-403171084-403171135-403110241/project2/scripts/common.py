from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BASE_CONFIG = PROJECT_ROOT / "configs" / "base_config.json"
DEFAULT_POLICY_FILE = PROJECT_ROOT / "configs" / "policies.json"
DEFAULT_MANIFEST = PROJECT_ROOT / "traces" / "manifest_final.csv"


@dataclass(frozen=True)
class TraceSpec:
    name: str
    path: Path
    trace_class: str
    notes: str = ""


def load_policy_groups(path: Path = DEFAULT_POLICY_FILE) -> dict[str, list[str]]:
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    return {key: list(value) for key, value in data.items() if isinstance(value, list)}


def all_policies(path: Path = DEFAULT_POLICY_FILE) -> list[str]:
    groups = load_policy_groups(path)
    return groups.get("baseline", []) + groups.get("advanced", []) + groups.get("bonus", [])


def parse_policy_selection(value: str | None, policy_file: Path = DEFAULT_POLICY_FILE) -> list[str]:
    available = all_policies(policy_file)
    if not value:
        return available
    selected = [item.strip() for item in value.split(",") if item.strip()]
    unknown = sorted(set(selected) - set(available))
    if unknown:
        raise ValueError(f"Unknown policies: {', '.join(unknown)}")
    return selected


def load_traces(manifest: Path) -> list[TraceSpec]:
    manifest = manifest.resolve()
    if not manifest.exists():
        raise FileNotFoundError(
            f"Trace manifest not found: {manifest}. Copy traces/manifest.example.csv to traces/manifest.csv and edit paths."
        )

    traces: list[TraceSpec] = []
    with manifest.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(row for row in handle if not row.lstrip().startswith("#"))
        required = {"name", "path", "class"}
        if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
            raise ValueError(f"Manifest must contain columns: {', '.join(sorted(required))}")
        for row in reader:
            name = (row.get("name") or "").strip()
            raw_path = (row.get("path") or "").strip()
            trace_class = (row.get("class") or "").strip()
            notes = (row.get("notes") or "").strip()
            if not name or not raw_path:
                continue
            trace_path = Path(raw_path).expanduser()
            if not trace_path.is_absolute():
                trace_path = (manifest.parent / trace_path).resolve()
            traces.append(TraceSpec(name=name, path=trace_path, trace_class=trace_class, notes=notes))

    if not traces:
        raise ValueError(f"No usable traces found in {manifest}")
    duplicate_names = sorted({trace.name for trace in traces if sum(t.name == trace.name for t in traces) > 1})
    if duplicate_names:
        raise ValueError(f"Duplicate trace names: {', '.join(duplicate_names)}")
    return traces


def ensure_paths_exist(traces: Sequence[TraceSpec]) -> None:
    missing = [trace.path for trace in traces if not trace.path.is_file()]
    if missing:
        lines = "\n".join(f"  - {path}" for path in missing)
        raise FileNotFoundError(f"The following trace files do not exist:\n{lines}")


def executable_name(policy: str) -> str:
    return f"champsim_{policy}"


def write_policy_config(base_config: Path, output: Path, policy: str) -> Path:
    with base_config.open("r", encoding="utf-8") as handle:
        config = json.load(handle)
    config["executable_name"] = executable_name(policy)
    config.setdefault("LLC", {})["replacement"] = policy
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8") as handle:
        json.dump(config, handle, indent=2, ensure_ascii=False)
        handle.write("\n")
    return output


def markdown_table(headers: Sequence[str], rows: Iterable[Sequence[object]]) -> str:
    escaped_headers = [str(item).replace("|", "\\|") for item in headers]
    lines = ["| " + " | ".join(escaped_headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    for row in rows:
        lines.append("| " + " | ".join(str(item).replace("|", "\\|") for item in row) + " |")
    return "\n".join(lines)
