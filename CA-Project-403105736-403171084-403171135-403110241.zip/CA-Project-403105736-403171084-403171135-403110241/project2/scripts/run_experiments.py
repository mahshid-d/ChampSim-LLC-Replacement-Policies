#!/usr/bin/env python3
from __future__ import annotations

import argparse
import concurrent.futures
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from common import (
    DEFAULT_BASE_CONFIG,
    DEFAULT_MANIFEST,
    DEFAULT_POLICY_FILE,
    TraceSpec,
    ensure_paths_exist,
    executable_name,
    load_traces,
    parse_policy_selection,
    write_policy_config,
)
from install_policies import validate_champsim_root
from parse_results import parse_output


@dataclass(frozen=True)
class RunJob:
    policy: str
    trace: TraceSpec
    binary: Path
    output: Path
    warmup: int
    simulation: int


def run_command(command: Sequence[str], cwd: Path, log_path: Path | None = None) -> None:
    if log_path is None:
        subprocess.run(command, cwd=cwd, check=True)
        return
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", encoding="utf-8") as log:
        log.write("COMMAND: " + " ".join(command) + "\n\n")
        log.flush()
        subprocess.run(command, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, check=True, text=True)


def build_policy(root: Path, base_config: Path, policy: str, config_dir: Path, build_log_dir: Path, make_jobs: int) -> Path:
    config = write_policy_config(base_config, config_dir / f"{policy}.json", policy)
    config_log = build_log_dir / f"{policy}.config.log"
    make_log = build_log_dir / f"{policy}.make.log"
    clean_log = build_log_dir / f"{policy}.clean.log"
    run_command(["make", "clean"], cwd=root, log_path=clean_log)
    run_command([str(root / "config.sh"), str(config)], cwd=root, log_path=config_log)
    run_command(["make", f"-j{make_jobs}"], cwd=root, log_path=make_log)
    binary = root / "bin" / executable_name(policy)
    if not binary.is_file():
        raise FileNotFoundError(f"Build succeeded but binary was not found: {binary}")
    return binary



def output_is_complete(path: Path) -> bool:
    if not path.is_file() or path.stat().st_size == 0:
        return False
    try:
        parse_output(path)
    except (OSError, ValueError):
        return False
    return True


def run_job(job: RunJob, champsim_root: Path) -> tuple[str, str, bool, str]:
    command = [
        str(job.binary),
        "--warmup-instructions",
        str(job.warmup),
        "--simulation-instructions",
        str(job.simulation),
        str(job.trace.path),
    ]
    try:
        run_command(command, cwd=champsim_root, log_path=job.output)
        return job.policy, job.trace.name, True, str(job.output)
    except subprocess.CalledProcessError as exc:
        return job.policy, job.trace.name, False, f"exit={exc.returncode}; log={job.output}"


def main() -> int:
    parser = argparse.ArgumentParser(description="Build ChampSim policies and run the complete policy × trace matrix.")
    parser.add_argument("--champsim-root", required=True, type=Path)
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--base-config", type=Path, default=DEFAULT_BASE_CONFIG)
    parser.add_argument("--policy-file", type=Path, default=DEFAULT_POLICY_FILE)
    parser.add_argument("--policies", help="Comma-separated subset. Default: all policies listed in configs/policies.json.")
    parser.add_argument("--warmup", type=int, default=50_000_000)
    parser.add_argument("--simulation", type=int, default=200_000_000)
    parser.add_argument("--make-jobs", type=int, default=max(1, min(8, os.cpu_count() or 1)))
    parser.add_argument("--run-jobs", type=int, default=1, help="Concurrent simulations; keep low to avoid memory pressure.")
    parser.add_argument("--output-dir", type=Path, default=Path("results/raw"))
    parser.add_argument("--generated-config-dir", type=Path, default=Path("generated_configs"))
    parser.add_argument("--build-log-dir", type=Path, default=Path("results/build_logs"))
    parser.add_argument("--skip-build", action="store_true", help="Use already-built bin/champsim_<policy> binaries.")
    parser.add_argument("--resume", action="store_true", help="Skip outputs that contain parseable final IPC and LLC statistics.")
    args = parser.parse_args()

    if args.warmup < 0 or args.simulation <= 0:
        parser.error("--warmup must be nonnegative and --simulation must be positive")
    if args.make_jobs <= 0 or args.run_jobs <= 0:
        parser.error("job counts must be positive")

    root = args.champsim_root.expanduser().resolve()
    validate_champsim_root(root)
    traces = load_traces(args.manifest)
    ensure_paths_exist(traces)
    policies = parse_policy_selection(args.policies, args.policy_file)

    output_dir = args.output_dir.resolve()
    config_dir = args.generated_config_dir.resolve()
    build_log_dir = args.build_log_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    pending: dict[str, list[TraceSpec]] = {}
    skipped = 0
    for policy in policies:
        policy_pending: list[TraceSpec] = []
        for trace in traces:
            output = output_dir / policy / f"{trace.name}.txt"
            if args.resume and output_is_complete(output):
                print(f"[SKIP] {policy:12s} {trace.name:24s} valid output exists", flush=True)
                skipped += 1
            else:
                policy_pending.append(trace)
        if policy_pending:
            pending[policy] = policy_pending

    if not pending:
        print(f"Nothing to run; {skipped} completed simulations were reused.")
        return 0

    binaries: dict[str, Path] = {}
    for policy in pending:
        if args.skip_build:
            binary = root / "bin" / executable_name(policy)
            if not binary.is_file():
                raise FileNotFoundError(f"Missing binary for --skip-build: {binary}")
        else:
            print(f"[BUILD] {policy}", flush=True)
            binary = build_policy(root, args.base_config.resolve(), policy, config_dir, build_log_dir, args.make_jobs)
        binaries[policy] = binary

    jobs = [
        RunJob(
            policy=policy,
            trace=trace,
            binary=binaries[policy],
            output=output_dir / policy / f"{trace.name}.txt",
            warmup=args.warmup,
            simulation=args.simulation,
        )
        for policy, policy_traces in pending.items()
        for trace in policy_traces
    ]

    failures: list[tuple[str, str, str]] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.run_jobs) as executor:
        futures = [executor.submit(run_job, job, root) for job in jobs]
        for future in concurrent.futures.as_completed(futures):
            policy, trace, ok, detail = future.result()
            print(f"[{'OK' if ok else 'FAIL'}] {policy:10s} {trace:24s} {detail}", flush=True)
            if not ok:
                failures.append((policy, trace, detail))

    if failures:
        print("\nFailed simulations:", file=sys.stderr)
        for policy, trace, detail in failures:
            print(f"  {policy}/{trace}: {detail}", file=sys.stderr)
        return 2
    print(f"Completed {len(jobs)} new simulations; reused {skipped} existing outputs.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
