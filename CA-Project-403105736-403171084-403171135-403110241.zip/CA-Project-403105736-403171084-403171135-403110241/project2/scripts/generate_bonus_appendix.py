#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path


def esc(value: str) -> str:
    return value.replace("_", r"\_")


def geometric_mean(values: list[float]) -> float:
    positive = [v for v in values if v > 0 and math.isfinite(v)]
    if not positive:
        return math.nan
    return math.exp(sum(math.log(v) for v in positive) / len(positive))


def row(*cells: object) -> str:
    return " & ".join(str(cell) for cell in cells) + r" \\"


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate the LaTeX bonus chapter from parsed results.")
    parser.add_argument("--detailed", type=Path, default=Path("results/final/tables/detailed_results.csv"))
    parser.add_argument("--summary", type=Path, default=Path("results/final/tables/summary_by_policy.csv"))
    parser.add_argument("--output", type=Path, default=Path("report/bonus_appendix.tex"))
    args = parser.parse_args()

    rows = list(csv.DictReader(args.detailed.open(encoding="utf-8")))
    summary = list(csv.DictReader(args.summary.open(encoding="utf-8")))
    matrix: dict[str, dict[str, dict[str, str]]] = defaultdict(dict)
    for item in rows:
        matrix[item["trace"]][item["policy"]] = item
    present = {item["policy"] for item in rows}

    output: list[str] = [
        r"\chapter{بخش‌های امتیازی}",
        (
            r"این فصل دو مورد امتیازی اصلی را مستند می‌کند: سیاست ترکیبی جدید \en{SHiP-BRRIP} "
            r"و خط لوله اجرای خودکار افزایشی. مقایسه \en{SHiP} با \en{SRRIP}/\en{DRRIP} "
            r"و تحلیل پهنای باند به عنوان ارزیابی‌های تکمیلی گزارش می‌شوند."
        ),
    ]

    output.append(r"\section{مقایسه SHiP با SRRIP و DRRIP}")
    if {"srrip", "drrip", "ship"}.issubset(present):
        output.extend(
            [
                r"\begin{latin}",
                r"\begin{center}",
                r"\small",
                r"\begin{tabular}{lrrrrrr}",
                r"\toprule",
                row("Trace", "IPC SHiP", "IPC SRRIP", "IPC DRRIP", "SHiP/SRRIP", "SHiP/DRRIP", "MPKI SHiP"),
                r"\midrule",
            ]
        )
        ship_vs_srrip: list[float] = []
        ship_vs_drrip: list[float] = []
        for trace in sorted(matrix):
            policies = matrix[trace]
            if not {"srrip", "drrip", "ship"}.issubset(policies):
                continue
            ship = float(policies["ship"]["ipc"])
            srrip = float(policies["srrip"]["ipc"])
            drrip = float(policies["drrip"]["ipc"])
            ship_vs_srrip.append(ship / srrip)
            ship_vs_drrip.append(ship / drrip)
            output.append(
                row(
                    esc(trace),
                    f"{ship:.5f}",
                    f"{srrip:.5f}",
                    f"{drrip:.5f}",
                    f"{ship / srrip:.4f}",
                    f"{ship / drrip:.4f}",
                    f"{float(policies['ship']['mpki']):.3f}",
                )
            )
        output.extend([r"\bottomrule", r"\end{tabular}", r"\end{center}", r"\end{latin}"])
        output.append(
            "میانگین هندسی نسبت "
            f"IPC(SHiP)/IPC(SRRIP) برابر {geometric_mean(ship_vs_srrip):.4f} و نسبت "
            f"IPC(SHiP)/IPC(DRRIP) برابر {geometric_mean(ship_vs_drrip):.4f} است."
        )
        output.extend([
            r"\IfFileExists{figures/04_bonus_ship_vs_rrip_ipc.png}{",
            r"\begin{figure}[H]\centering\includegraphics[width=0.95\textwidth]{figures/04_bonus_ship_vs_rrip_ipc.png}",
            r"\caption{مقایسه IPC سیاست‌های SHiP، SRRIP و DRRIP}\end{figure}}{}",
        ])
    else:
        output.append(
            r"نتایج این بخش هنوز اجرا نشده‌اند. برای ادعای این امتیاز باید خروجی چهار ردپا برای هر سه سیاست "
            r"\en{SRRIP}، \en{DRRIP} و \en{SHiP} موجود باشد."
        )

    output.append(r"\section{سیاست ترکیبی جدید SHiP-BRRIP}")
    if "ship_brrip" in present:
        output.extend(
            [
                (
                    r"سیاست پیشنهادی از جدول تاریخچه امضای PC برای انتخاب میان ورود شبیه SRRIP و BRRIP استفاده "
                    r"می‌کند و در برخورد، RRPV را به صفر می‌رساند."
                ),
                r"\begin{latin}",
                r"\begin{center}",
                r"\small",
                r"\begin{tabular}{lrrrr}",
                r"\toprule",
                row("Trace", "IPC hybrid", "Best reference", "IPC reference", "Ratio"),
                r"\midrule",
            ]
        )
        ratios: list[float] = []
        for trace in sorted(matrix):
            policies = matrix[trace]
            if "ship_brrip" not in policies:
                continue
            references = [p for p in ("srrip", "drrip", "ship", "lru") if p in policies]
            reference = max(references, key=lambda p: float(policies[p]["ipc"]))
            hybrid = float(policies["ship_brrip"]["ipc"])
            reference_ipc = float(policies[reference]["ipc"])
            ratios.append(hybrid / reference_ipc)
            output.append(
                row(esc(trace), f"{hybrid:.5f}", reference, f"{reference_ipc:.5f}", f"{hybrid / reference_ipc:.4f}")
            )
        output.extend([r"\bottomrule", r"\end{tabular}", r"\end{center}", r"\end{latin}"])
        output.append(
            f"میانگین هندسی نسبت سیاست ترکیبی به بهترین مرجع موجود برابر {geometric_mean(ratios):.4f} است."
        )
        output.extend([
            r"\IfFileExists{figures/06_bonus_ship_brrip_speedup.png}{",
            r"\begin{figure}[H]\centering\includegraphics[width=0.95\textwidth]{figures/06_bonus_ship_brrip_speedup.png}",
            r"\caption{شتاب سیاست ترکیبی SHiP-BRRIP و سیاست‌های مرجع نسبت به LRU}\end{figure}}{}",
        ])
    else:
        output.append(
            r"کد سیاست در مسیر \file{replacement/ship\_brrip} وجود دارد، اما برای ادعای نتیجه تجربی باید "
            r"چهار اجرای این سیاست انجام شود."
        )

    output.extend(
        [
            r"\section{تحلیل پهنای باند حافظه اصلی}",
            (
                r"تعداد درخواست‌های خواندن و نوشتن DRAM از بخش DRAM Statistics خروجی ChampSim استخراج شد. "
                r"با فرض انتقال یک بلوک 64 بایتی برای هر درخواست، پهنای باند خواندن، نوشتن و مجموع بر حسب "
                r"GB/s تخمین زده شد. این مقدار هنوز سربار پروتکل و جزئیات burst را مدل نمی‌کند، اما از proxy "
                r"مبتنی صرف بر LLC miss دقیق‌تر است."
            ),
            r"\begin{latin}",
            r"\begin{center}",
            r"\small",
            r"\begin{tabular}{lrrr}",
            r"\toprule",
            row("Policy", "Mean DRAM BW (GB/s)", "Mean MPKI", "GeoMean speedup"),
            r"\midrule",
        ]
    )
    bandwidth_field = "mean_estimated_dram_total_bandwidth_gbps"
    if not summary or bandwidth_field not in summary[0]:
        bandwidth_field = "mean_estimated_read_bandwidth_gbps"
    bandwidth_rows = [item for item in summary if item.get(bandwidth_field)]
    bandwidth_rows.sort(key=lambda item: float(item[bandwidth_field]))
    for item in bandwidth_rows:
        output.append(
            row(
                esc(item["policy"]),
                f"{float(item[bandwidth_field]):.4f}",
                f"{float(item['mean_mpki']):.3f}",
                f"{float(item['geomean_speedup_vs_lru']):.4f}",
            )
        )
    output.extend([r"\bottomrule", r"\end{tabular}", r"\end{center}", r"\end{latin}"])
    output.extend([
        r"\IfFileExists{figures/05_bonus_memory_bandwidth_proxy.png}{",
        r"\begin{figure}[H]\centering\includegraphics[width=0.95\textwidth]{figures/05_bonus_memory_bandwidth_proxy.png}",
        r"\caption{برآورد پهنای باند مجموع DRAM بر اساس شمارنده‌های RQ/WQ شبیه‌ساز}\end{figure}}{}",
    ])

    output.extend(
        [
            r"\section{اجرای خودکار افزایشی}",
            (
                r"گزینه \file{--resume} فقط خروجی‌هایی را reuse می‌کند که IPC و آمار LLC آن‌ها قابل parse باشد. "
                r"اسکریپت \file{run\_bonus\_only\_v2.sh} چهار سیاست تکمیلی را با تنظیم دقیق آزمایش اصلی اجرا و "
                r"سپس CSV، نمودارها، اعتبارسنجی و این فصل را بازتولید می‌کند."
            ),
        ]
    )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n\n".join(output) + "\n", encoding="utf-8")
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
