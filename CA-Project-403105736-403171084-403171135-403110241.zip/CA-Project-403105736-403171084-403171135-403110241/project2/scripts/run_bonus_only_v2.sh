#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 1 ]]; then
  echo "Usage: $0 /path/to/ChampSim [manifest]" >&2
  exit 2
fi
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CHAMPSIM_ROOT="$(cd "$1" && pwd)"
MANIFEST="${2:-$PROJECT_ROOT/traces/manifest_final.csv}"
PYTHON="${PYTHON:-python3}"

"$PYTHON" "$PROJECT_ROOT/scripts/install_policies.py" --champsim-root "$CHAMPSIM_ROOT" --force
"$PYTHON" "$PROJECT_ROOT/scripts/run_experiments.py" \
  --champsim-root "$CHAMPSIM_ROOT" \
  --manifest "$MANIFEST" \
  --base-config "$PROJECT_ROOT/configs/base_config.json" \
  --policy-file "$PROJECT_ROOT/configs/policies.json" \
  --policies srrip,drrip,ship,ship_brrip \
  --warmup 1000000 --simulation 5000000 \
  --make-jobs 4 --run-jobs 2 \
  --output-dir "$PROJECT_ROOT/results/final/raw" \
  --generated-config-dir "$PROJECT_ROOT/generated_configs_final" \
  --build-log-dir "$PROJECT_ROOT/results/final/build_logs" \
  --resume

"$PYTHON" "$PROJECT_ROOT/scripts/parse_results.py" \
  --raw-dir "$PROJECT_ROOT/results/final/raw" \
  --manifest "$MANIFEST" \
  --base-config "$PROJECT_ROOT/configs/base_config.json" \
  --output-dir "$PROJECT_ROOT/results/final/tables" --baseline lru
"$PYTHON" "$PROJECT_ROOT/scripts/validate_results.py" --require-bonus
"$PYTHON" "$PROJECT_ROOT/scripts/plot_results.py" \
  --input "$PROJECT_ROOT/results/final/tables/detailed_results.csv" \
  --output-dir "$PROJECT_ROOT/results/final/figures" \
  --policy-file "$PROJECT_ROOT/configs/policies.json"
"$PYTHON" "$PROJECT_ROOT/scripts/generate_bonus_appendix.py" \
  --detailed "$PROJECT_ROOT/results/final/tables/detailed_results.csv" \
  --summary "$PROJECT_ROOT/results/final/tables/summary_by_policy.csv" \
  --output "$PROJECT_ROOT/report/bonus_appendix.tex"
cp "$PROJECT_ROOT/results/final/tables/"*.csv "$PROJECT_ROOT/report/data/"
cp "$PROJECT_ROOT/results/final/figures/"*.png "$PROJECT_ROOT/report/figures/"
echo "Bonus pipeline complete. Recompile report/report.tex with XeLaTeX/Biber."
