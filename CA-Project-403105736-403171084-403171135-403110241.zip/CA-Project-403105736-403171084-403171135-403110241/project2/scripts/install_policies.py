#!/usr/bin/env python3
from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from common import DEFAULT_POLICY_FILE, PROJECT_ROOT, load_policy_groups


def validate_champsim_root(root: Path) -> None:
    required = [root / "config.sh", root / "replacement", root / "Makefile"]
    missing = [path for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError("Not a supported ChampSim root; missing: " + ", ".join(str(path) for path in missing))

    lru_header = root / "replacement" / "lru" / "lru.h"
    if lru_header.exists():
        text = lru_header.read_text(encoding="utf-8", errors="ignore")
        if "modules::replacement" not in text:
            raise RuntimeError(
                "This package targets the current object-module ChampSim API. The detected tree appears to use an older API."
            )


def main() -> int:
    parser = argparse.ArgumentParser(description="Install custom replacement policies into a ChampSim checkout.")
    parser.add_argument("--champsim-root", required=True, type=Path)
    parser.add_argument("--force", action="store_true", help="Overwrite existing custom policy directories.")
    args = parser.parse_args()

    root = args.champsim_root.expanduser().resolve()
    validate_champsim_root(root)
    groups = load_policy_groups(DEFAULT_POLICY_FILE)
    custom = groups["implemented_in_this_package"]
    built_in = groups["built_in_in_current_champsim"]

    source_root = PROJECT_ROOT / "replacement"
    destination_root = root / "replacement"

    for policy in custom:
        source = source_root / policy
        destination = destination_root / policy
        if destination.exists():
            if not args.force:
                print(f"SKIP {policy}: {destination} already exists (use --force to overwrite)")
                continue
            shutil.rmtree(destination)
        shutil.copytree(source, destination)
        print(f"INSTALLED {policy} -> {destination}")

    missing_builtins = [policy for policy in built_in if not (destination_root / policy).is_dir()]
    if missing_builtins:
        print("WARNING: expected built-in policies not found: " + ", ".join(missing_builtins))
        print("The installed ChampSim revision may differ from the targeted current release.")
    else:
        print("Built-in policies detected: " + ", ".join(built_in))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
