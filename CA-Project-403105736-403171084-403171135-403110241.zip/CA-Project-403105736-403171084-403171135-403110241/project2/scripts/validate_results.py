#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import math
import re
import statistics
from pathlib import Path

CORE_POLICIES = {"lru", "fifo", "mru", "random", "brrip", "bip", "dip", "tree_plru"}
BONUS_POLICIES = {"srrip", "drrip", "ship", "ship_brrip"}
TRACES = {"h264ref_64B", "zeusmp_10B", "mcf_217B", "lbm_1274B"}
EXPECTED_WARMUP = 1_000_000
EXPECTED_SIMULATION = 5_000_000
BLOCK_SIZE = 64
FREQUENCY_MHZ = 4000.0

NUMBER = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?"
IPC_RE = re.compile(
    rf"CPU\s+\d+\s+(?:cumulative\s+)?IPC\s*:\s*(?P<ipc>{NUMBER})"
    rf"(?:[^\n]*?instructions\s*:\s*(?P<instructions>\d+)"
    rf"[^\n]*?cycles\s*:\s*(?P<cycles>\d+))?",
    re.IGNORECASE,
)
LLC_RE = re.compile(
    r"LLC\s+TOTAL\s+ACCESS\s*:\s*(?P<access>\d+)\s+"
    r"HIT\s*:\s*(?P<hit>\d+)\s+MISS\s*:\s*(?P<miss>\d+)",
    re.IGNORECASE,
)
DRAM_RQ_RE = re.compile(
    r"Channel\s+\d+\s+RQ\s+ROW_BUFFER_HIT\s*:\s*(?P<hit>\d+)\s*\n\s*"
    r"ROW_BUFFER_MISS\s*:\s*(?P<miss>\d+)",
    re.IGNORECASE,
)
DRAM_WQ_RE = re.compile(
    r"Channel\s+\d+\s+WQ\s+ROW_BUFFER_HIT\s*:\s*(?P<hit>\d+)\s*\n\s*"
    r"ROW_BUFFER_MISS\s*:\s*(?P<miss>\d+)",
    re.IGNORECASE,
)
WARMUP_RE = re.compile(r"--warmup-instructions\s+(\d+)")
SIM_RE = re.compile(r"--simulation-instructions\s+(\d+)")


def last_match(pattern: re.Pattern[str], text: str) -> re.Match[str] | None:
    matches = list(pattern.finditer(text))
    return matches[-1] if matches else None


def close(a: float, b: float, tol: float = 1e-10) -> bool:
    return math.isclose(a, b, rel_tol=tol, abs_tol=tol)


def geomean(values: list[float]) -> float:
    return math.exp(statistics.fmean(math.log(value) for value in values))


def main() -> int:
    parser = argparse.ArgumentParser(description="Strict validation of final ChampSim raw outputs and tables.")
    parser.add_argument("--detailed", type=Path, default=Path("results/final/tables/detailed_results.csv"))
    parser.add_argument("--summary", type=Path, default=Path("results/final/tables/summary_by_policy.csv"))
    parser.add_argument("--raw-dir", type=Path, default=Path("results/final/raw"))
    parser.add_argument("--require-bonus", action="store_true")
    args = parser.parse_args()

    policies = CORE_POLICIES | (BONUS_POLICIES if args.require_bonus else set())
    expected_pairs = {(policy, trace) for policy in policies for trace in TRACES}
    expected_raw = {args.raw_dir / policy / f"{trace}.txt" for policy, trace in expected_pairs}
    errors: list[str] = []

    if not args.detailed.is_file():
        errors.append(f"Missing detailed CSV: {args.detailed}")
        rows: list[dict[str, str]] = []
    else:
        rows = list(csv.DictReader(args.detailed.open(encoding="utf-8", newline="")))

    if not args.summary.is_file():
        errors.append(f"Missing summary CSV: {args.summary}")
        summary_rows: list[dict[str, str]] = []
    else:
        summary_rows = list(csv.DictReader(args.summary.open(encoding="utf-8", newline="")))

    all_raw = set(args.raw_dir.glob("*/*.txt"))
    for path in sorted(expected_raw - all_raw):
        errors.append(f"Missing raw output: {path}")
    for path in sorted(all_raw - expected_raw):
        errors.append(f"Unexpected raw output: {path}")

    pairs = [(row.get("policy", ""), row.get("trace", "")) for row in rows]
    found_pairs = set(pairs)
    if len(rows) != len(expected_pairs):
        errors.append(f"Detailed rows: expected {len(expected_pairs)}, found {len(rows)}")
    if len(found_pairs) != len(pairs):
        errors.append("Duplicate policy/trace rows exist")
    for pair in sorted(expected_pairs - found_pairs):
        errors.append(f"Missing CSV combination: {pair}")
    for pair in sorted(found_pairs - expected_pairs):
        errors.append(f"Unexpected CSV combination: {pair}")

    row_by_pair = {(row["policy"], row["trace"]): row for row in rows if row.get("policy") and row.get("trace")}

    for policy, trace in sorted(expected_pairs):
        path = args.raw_dir / policy / f"{trace}.txt"
        if not path.is_file() or path.stat().st_size == 0:
            continue

        text = path.read_text(encoding="utf-8", errors="replace")
        if "ChampSim completed all CPUs" not in text:
            errors.append(f"{policy}/{trace}: completion marker missing")

        warmup = WARMUP_RE.search(text)
        simulation = SIM_RE.search(text)
        if warmup is None or int(warmup.group(1)) != EXPECTED_WARMUP:
            errors.append(f"{policy}/{trace}: incorrect or missing warmup count")
        if simulation is None or int(simulation.group(1)) != EXPECTED_SIMULATION:
            errors.append(f"{policy}/{trace}: incorrect or missing simulation count")

        ipc_match = last_match(IPC_RE, text)
        llc_match = last_match(LLC_RE, text)
        rq_match = last_match(DRAM_RQ_RE, text)
        wq_match = last_match(DRAM_WQ_RE, text)
        if ipc_match is None or llc_match is None or rq_match is None or wq_match is None:
            errors.append(f"{policy}/{trace}: final IPC/LLC/DRAM statistics missing")
            continue
        if ipc_match.group("instructions") is None or ipc_match.group("cycles") is None:
            errors.append(f"{policy}/{trace}: instructions/cycles missing")
            continue

        ipc = float(ipc_match.group("ipc"))
        instructions = int(ipc_match.group("instructions"))
        cycles = int(ipc_match.group("cycles"))
        accesses = int(llc_match.group("access"))
        hits = int(llc_match.group("hit"))
        misses = int(llc_match.group("miss"))
        rq_hits = int(rq_match.group("hit"))
        rq_misses = int(rq_match.group("miss"))
        wq_hits = int(wq_match.group("hit"))
        wq_misses = int(wq_match.group("miss"))
        read_requests = rq_hits + rq_misses
        write_requests = wq_hits + wq_misses
        total_requests = read_requests + write_requests

        if instructions < EXPECTED_SIMULATION or cycles <= 0 or accesses <= 0:
            errors.append(f"{policy}/{trace}: invalid execution counts")
        if hits + misses != accesses:
            errors.append(f"{policy}/{trace}: hits + misses != accesses")

        row = row_by_pair.get((policy, trace))
        if row is None:
            continue

        integer_expected = {
            "instructions": instructions,
            "cycles": cycles,
            "llc_accesses": accesses,
            "llc_hits": hits,
            "llc_misses": misses,
            "dram_rq_row_hits": rq_hits,
            "dram_rq_row_misses": rq_misses,
            "dram_wq_row_hits": wq_hits,
            "dram_wq_row_misses": wq_misses,
            "dram_read_requests": read_requests,
            "dram_write_requests": write_requests,
            "dram_total_requests": total_requests,
        }
        for field, expected in integer_expected.items():
            if field not in row or int(row[field]) != expected:
                errors.append(f"{policy}/{trace}: CSV {field} does not match raw output")

        if not close(float(row["ipc"]), ipc):
            errors.append(f"{policy}/{trace}: CSV IPC does not match raw output")

        seconds = cycles / (FREQUENCY_MHZ * 1_000_000.0)
        float_expected = {
            "hit_rate": hits / accesses,
            "miss_rate": misses / accesses,
            "mpki": misses * 1000.0 / instructions,
            "llc_read_traffic_bytes_lower_bound": misses * BLOCK_SIZE,
            "estimated_read_bandwidth_gbps": misses * BLOCK_SIZE / seconds / 1_000_000_000.0,
            "dram_read_traffic_bytes_estimate": read_requests * BLOCK_SIZE,
            "dram_write_traffic_bytes_estimate": write_requests * BLOCK_SIZE,
            "dram_total_traffic_bytes_estimate": total_requests * BLOCK_SIZE,
            "estimated_dram_read_bandwidth_gbps": read_requests * BLOCK_SIZE / seconds / 1_000_000_000.0,
            "estimated_dram_write_bandwidth_gbps": write_requests * BLOCK_SIZE / seconds / 1_000_000_000.0,
            "estimated_dram_total_bandwidth_gbps": total_requests * BLOCK_SIZE / seconds / 1_000_000_000.0,
        }
        for field, expected in float_expected.items():
            if field not in row or not close(float(row[field]), float(expected)):
                errors.append(f"{policy}/{trace}: incorrect derived field {field}")

        if row.get("access_consistent", "").lower() != "true":
            errors.append(f"{policy}/{trace}: access_consistent is not true")
        if int(row.get("block_size_bytes", 0)) != BLOCK_SIZE:
            errors.append(f"{policy}/{trace}: wrong block size")
        if not close(float(row.get("cpu_frequency_mhz", "nan")), FREQUENCY_MHZ):
            errors.append(f"{policy}/{trace}: wrong CPU frequency")

    baseline_ipc = {
        trace: float(row_by_pair[("lru", trace)]["ipc"])
        for trace in TRACES if ("lru", trace) in row_by_pair
    }
    for policy, trace in sorted(expected_pairs):
        row = row_by_pair.get((policy, trace))
        if row is None or trace not in baseline_ipc:
            continue
        expected_speedup = float(row["ipc"]) / baseline_ipc[trace]
        if not close(float(row["speedup_vs_lru"]), expected_speedup):
            errors.append(f"{policy}/{trace}: incorrect speedup_vs_lru")
        if policy == "lru" and not close(float(row["speedup_vs_lru"]), 1.0):
            errors.append(f"{trace}: LRU speedup is not 1")

    summary_by_policy = {row.get("policy", ""): row for row in summary_rows}
    if len(summary_rows) != len(policies):
        errors.append(f"Summary rows: expected {len(policies)}, found {len(summary_rows)}")
    if set(summary_by_policy) != policies:
        errors.append("Summary policy set does not match expected policy set")

    for policy in sorted(policies):
        policy_rows = [row_by_pair[(policy, trace)] for trace in TRACES if (policy, trace) in row_by_pair]
        summary_row = summary_by_policy.get(policy)
        if summary_row is None or len(policy_rows) != len(TRACES):
            continue

        expected_summary = {
            "trace_count": len(policy_rows),
            "mean_ipc": statistics.fmean(float(row["ipc"]) for row in policy_rows),
            "mean_miss_rate": statistics.fmean(float(row["miss_rate"]) for row in policy_rows),
            "mean_mpki": statistics.fmean(float(row["mpki"]) for row in policy_rows),
            "mean_estimated_read_bandwidth_gbps": statistics.fmean(float(row["estimated_read_bandwidth_gbps"]) for row in policy_rows),
            "mean_estimated_dram_read_bandwidth_gbps": statistics.fmean(float(row["estimated_dram_read_bandwidth_gbps"]) for row in policy_rows),
            "mean_estimated_dram_write_bandwidth_gbps": statistics.fmean(float(row["estimated_dram_write_bandwidth_gbps"]) for row in policy_rows),
            "mean_estimated_dram_total_bandwidth_gbps": statistics.fmean(float(row["estimated_dram_total_bandwidth_gbps"]) for row in policy_rows),
            "geomean_speedup_vs_lru": geomean([float(row["speedup_vs_lru"]) for row in policy_rows]),
            "min_speedup_vs_lru": min(float(row["speedup_vs_lru"]) for row in policy_rows),
            "max_speedup_vs_lru": max(float(row["speedup_vs_lru"]) for row in policy_rows),
        }

        if int(summary_row["trace_count"]) != expected_summary["trace_count"]:
            errors.append(f"{policy}: incorrect summary trace_count")
        for field, expected in expected_summary.items():
            if field == "trace_count":
                continue
            if field not in summary_row or not close(float(summary_row[field]), float(expected)):
                errors.append(f"{policy}: incorrect summary field {field}")

    print(f"Expected policies: {len(policies)}")
    print(f"Expected combinations: {len(expected_pairs)}")
    print(f"Detailed rows: {len(rows)}")
    print(f"Raw output files: {len(all_raw)}")
    print(f"Summary rows: {len(summary_rows)}")

    if errors:
        print("VALIDATION FAILED")
        for error in errors:
            print(f" - {error}")
        return 1

    print("BONUS VALIDATION PASSED" if args.require_bonus else "CORE VALIDATION PASSED")
    print("Raw outputs, CSV metrics, speedups, DRAM estimates, and summary are mutually consistent.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
