#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CHAMPSIM_ROOT="${1:-$PROJECT_ROOT/ChampSim}"
MANIFEST="${2:-$PROJECT_ROOT/traces/manifest_final.csv}"

if [[ -n "${PYTHON:-}" ]]; then
  PY="$PYTHON"
elif [[ -x "$PROJECT_ROOT/.venv/bin/python" ]]; then
  PY="$PROJECT_ROOT/.venv/bin/python"
else
  PY="$(command -v python3)"
fi

POLICIES="lru,fifo,mru,random,brrip,bip,dip,tree_plru,srrip,drrip,ship,ship_brrip"

"$PY" "$PROJECT_ROOT/scripts/install_policies.py" \
  --champsim-root "$CHAMPSIM_ROOT" \
  --force

"$PY" "$PROJECT_ROOT/scripts/run_experiments.py" \
  --champsim-root "$CHAMPSIM_ROOT" \
  --manifest "$MANIFEST" \
  --base-config "$PROJECT_ROOT/configs/base_config.json" \
  --policies "$POLICIES" \
  --warmup 1000000 \
  --simulation 5000000 \
  --resume \
  --make-jobs 4 \
  --run-jobs 2 \
  --generated-config-dir "$PROJECT_ROOT/generated_configs_final" \
  --build-log-dir "$PROJECT_ROOT/results/final/build_logs" \
  --output-dir "$PROJECT_ROOT/results/final/raw"

"$PY" "$PROJECT_ROOT/scripts/parse_results.py" \
  --raw-dir "$PROJECT_ROOT/results/final/raw" \
  --manifest "$MANIFEST" \
  --output-dir "$PROJECT_ROOT/results/final/tables" \
  --baseline lru

"$PY" "$PROJECT_ROOT/scripts/validate_results.py" --require-bonus \
  | tee "$PROJECT_ROOT/results/final/VALIDATION_FINAL.txt"

"$PY" "$PROJECT_ROOT/scripts/plot_results.py" \
  --input "$PROJECT_ROOT/results/final/tables/detailed_results.csv" \
  --output-dir "$PROJECT_ROOT/results/final/figures" \
  --policy-file "$PROJECT_ROOT/configs/policies.json"

if [[ -f "$PROJECT_ROOT/scripts/generate_bonus_appendix.py" ]]; then
  "$PY" "$PROJECT_ROOT/scripts/generate_bonus_appendix.py" \
    --detailed "$PROJECT_ROOT/results/final/tables/detailed_results.csv" \
    --summary "$PROJECT_ROOT/results/final/tables/summary_by_policy.csv" \
    --output "$PROJECT_ROOT/report/bonus_appendix.tex"
fi

echo "Final 48-run pipeline completed successfully."
