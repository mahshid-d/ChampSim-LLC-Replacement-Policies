#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"

if [[ -x "$PROJECT_ROOT/.venv/bin/python" ]]; then
  PY="$PROJECT_ROOT/.venv/bin/python"
else
  PY="$(command -v python3)"
fi

bash tests/smoke_test.sh
"$PY" scripts/validate_results.py --require-bonus
PYTHON="$PY" bash scripts/preflight_nonreport.sh

cmp traces/manifest.csv traces/manifest_final.csv
! grep -q '/Users/' traces/manifest.csv
! grep -q '/Users/' traces/manifest_final.csv

test -s CHAMPSIM_REPRODUCE.md
test -s traces/trace_files/README.md
test -s tests/README.md

raw_count="$(find results/final/raw -type f -name '*.txt' | wc -l | tr -d ' ')"
row_count="$(tail -n +2 results/final/tables/detailed_results.csv | wc -l | tr -d ' ')"
figure_count="$(find results/final/figures -maxdepth 1 -type f -name '*.png' | wc -l | tr -d ' ')"

[[ "$raw_count" == "48" ]]
[[ "$row_count" == "48" ]]
[[ "$figure_count" -ge 6 ]]

junk_count="$(
  find . \
    \( -type d -name '__MACOSX' -o \
       -type f -name '.DS_Store' -o \
       -type f -name '._*' \) \
    | wc -l | tr -d ' '
)"
[[ "$junk_count" == "0" ]]

echo
echo "FINAL NON-REPORT DELIVERY PREFLIGHT PASSED"
echo "Smoke tests: passed"
echo "Raw outputs: $raw_count"
echo "Detailed rows: $row_count"
echo "Figures: $figure_count"
echo "Portable manifests: passed"
echo "Dependency documentation: present"
echo "macOS metadata: absent"
