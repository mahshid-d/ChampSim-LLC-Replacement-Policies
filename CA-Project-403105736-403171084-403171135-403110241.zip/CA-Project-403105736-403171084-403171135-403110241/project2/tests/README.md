# Tests

Run:

```bash
bash tests/smoke_test.sh
```

The smoke test compiles all eight custom modules against a minimal representation of the current ChampSim replacement API, executes deterministic behavior checks, tests the output parser, validates Python syntax, and generates sample configuration files. It is not a substitute for compiling inside the exact ChampSim checkout used for the experiment.
