#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from parse_results import parse_output  # noqa: E402


DRAM_STATS = """
Channel 0 RQ ROW_BUFFER_HIT: 10
  ROW_BUFFER_MISS: 20
Channel 0 WQ ROW_BUFFER_HIT: 5
  ROW_BUFFER_MISS: 6
"""


class ParserTests(unittest.TestCase):
    def test_standard_champsim_output(self) -> None:
        sample = f"""
ChampSim completed all CPUs
CPU 0 cumulative IPC: 1.25000 instructions: 200000000 cycles: 160000000
LLC TOTAL ACCESS: 1000000 HIT: 750000 MISS: 250000
{DRAM_STATS}
"""
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "sample.txt"
            path.write_text(sample, encoding="utf-8")
            metrics = parse_output(path)

        self.assertAlmostEqual(metrics["ipc"], 1.25)
        self.assertEqual(metrics["llc_misses"], 250000)
        self.assertAlmostEqual(metrics["miss_rate"], 0.25)
        self.assertAlmostEqual(metrics["mpki"], 1.25)
        self.assertTrue(metrics["access_consistent"])
        self.assertEqual(metrics["dram_read_requests"], 30)
        self.assertEqual(metrics["dram_write_requests"], 11)
        self.assertEqual(metrics["dram_total_requests"], 41)

    def test_last_statistics_block_is_used(self) -> None:
        sample = f"""
CPU 0 cumulative IPC: 0.500 instructions: 100 cycles: 200
LLC TOTAL ACCESS: 10 HIT: 1 MISS: 9
CPU 0 cumulative IPC: 2.000 instructions: 1000 cycles: 500
LLC TOTAL ACCESS: 100 HIT: 80 MISS: 20
{DRAM_STATS}
ChampSim completed all CPUs
"""
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "sample.txt"
            path.write_text(sample, encoding="utf-8")
            metrics = parse_output(path)

        self.assertAlmostEqual(metrics["ipc"], 2.0)
        self.assertEqual(metrics["llc_accesses"], 100)
        self.assertEqual(metrics["llc_hits"], 80)
        self.assertEqual(metrics["llc_misses"], 20)


if __name__ == "__main__":
    unittest.main()
