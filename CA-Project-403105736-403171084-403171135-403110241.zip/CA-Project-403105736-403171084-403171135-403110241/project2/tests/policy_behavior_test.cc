#include <cassert>
#include <iostream>

#include "fifo.h"
#include "mru.h"
#include "brrip.h"
#include "bip.h"
#include "dip.h"
#include "tree_plru.h"
#include "lfu.h"
#include "ship_brrip.h"

static champsim::address A{};
static champsim::cache_block blocks[4];

template <typename P>
void fill_all(P& p)
{
  for (long way = 0; way < 4; ++way)
    p.replacement_cache_fill(0, 0, way, A, champsim::address{static_cast<std::uint64_t>(way + 1)}, A, access_type::LOAD);
}

int main()
{
  CACHE cache;
  cache.NUM_SET = 64;
  cache.NUM_WAY = 4;

  fifo f(&cache);
  fill_all(f);
  assert(f.find_victim(0, 0, 0, blocks, A, A, access_type::LOAD) == 0);
  f.update_replacement_state(0, 0, 0, A, A, A, access_type::LOAD, 1);
  assert(f.find_victim(0, 0, 0, blocks, A, A, access_type::LOAD) == 0);

  mru m(&cache);
  fill_all(m);
  assert(m.find_victim(0, 0, 0, blocks, A, A, access_type::LOAD) == 3);
  m.update_replacement_state(0, 0, 1, A, A, A, access_type::LOAD, 1);
  assert(m.find_victim(0, 0, 0, blocks, A, A, access_type::LOAD) == 1);

  brrip br(&cache);
  fill_all(br);
  assert(br.find_victim(0, 0, 0, blocks, A, A, access_type::LOAD) == 0);
  br.update_replacement_state(0, 0, 0, A, A, A, access_type::LOAD, 1);
  assert(br.find_victim(0, 0, 0, blocks, A, A, access_type::LOAD) != 0);

  bip bi(&cache);
  fill_all(bi);
  assert(bi.find_victim(0, 0, 0, blocks, A, A, access_type::LOAD) == 3);
  bi.update_replacement_state(0, 0, 3, A, A, A, access_type::LOAD, 1);
  assert(bi.find_victim(0, 0, 0, blocks, A, A, access_type::LOAD) == 2);

  dip di(&cache);
  fill_all(di);
  assert(di.find_victim(0, 0, 0, blocks, A, A, access_type::LOAD) == 0);

  tree_plru tp(&cache);
  fill_all(tp);
  assert(tp.find_victim(0, 0, 0, blocks, A, A, access_type::LOAD) == 0);
  tp.update_replacement_state(0, 0, 0, A, A, A, access_type::LOAD, 1);
  assert(tp.find_victim(0, 0, 0, blocks, A, A, access_type::LOAD) == 2);

  lfu lf(&cache);
  fill_all(lf);
  assert(lf.find_victim(0, 0, 0, blocks, A, A, access_type::LOAD) == 0);
  lf.update_replacement_state(0, 0, 0, A, A, A, access_type::LOAD, 1);
  assert(lf.find_victim(0, 0, 0, blocks, A, A, access_type::LOAD) == 1);

  ship_brrip hybrid(&cache);
  fill_all(hybrid);
  assert(hybrid.find_victim(0, 0, 0, blocks, A, A, access_type::LOAD) == 0);
  hybrid.update_replacement_state(0, 0, 0, A, A, A, access_type::LOAD, 1);
  assert(hybrid.find_victim(0, 0, 0, blocks, A, A, access_type::LOAD) == 1);

  std::cout << "policy behavior tests passed\n";
}
