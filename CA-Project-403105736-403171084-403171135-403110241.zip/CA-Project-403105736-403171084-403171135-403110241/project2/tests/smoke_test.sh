#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
STUB="$PROJECT_ROOT/tests/stub"
BUILD="$PROJECT_ROOT/tests/build"
mkdir -p "$STUB"
rm -rf "$BUILD"
mkdir -p "$BUILD"

cat > "$STUB/cache.h" <<'HDR'
#ifndef TEST_CACHE_H
#define TEST_CACHE_H
#include <cstdint>
#include <type_traits>
namespace champsim {
namespace data::data_literals {
constexpr unsigned long long operator""_b(unsigned long long value) { return value; }
}
struct address {
  std::uint64_t value = 0;
  address() = default;
  address(std::uint64_t v) : value(v) {}
  template <auto Bits> address slice_lower() const {
    static_assert(Bits > 0 && Bits <= 64);
    if constexpr (Bits == 64)
      return *this;
    return address{value & ((std::uint64_t{1} << Bits) - 1)};
  }
  template <typename T> T to() const { return static_cast<T>(value); }
};
struct cache_block {};
}
enum class access_type : std::uint8_t { LOAD, RFO, PREFETCH, WRITE, TRANSLATION };
struct CACHE {
  long NUM_SET = 2048;
  long NUM_WAY = 16;
};
#endif
HDR

cat > "$STUB/modules.h" <<'HDR'
#ifndef TEST_MODULES_H
#define TEST_MODULES_H
struct CACHE;
namespace champsim::modules {
struct replacement {
  explicit replacement(CACHE*) {}
};
}
#endif
HDR

cat > "$STUB/champsim.h" <<'HDR'
#ifndef TEST_CHAMPSIM_H
#define TEST_CHAMPSIM_H
#include "cache.h"
#endif
HDR

for policy in fifo mru brrip bip dip tree_plru lfu ship_brrip; do
  g++ -std=c++17 -Wall -Wextra -Werror \
    -I"$STUB" -I"$PROJECT_ROOT/replacement/$policy" \
    -c "$PROJECT_ROOT/replacement/$policy/$policy.cc" \
    -o "$BUILD/$policy.o"
done

g++ -std=c++17 -Wall -Wextra -Werror \
  -I"$STUB" \
  -I"$PROJECT_ROOT/replacement/fifo" \
  -I"$PROJECT_ROOT/replacement/mru" \
  -I"$PROJECT_ROOT/replacement/brrip" \
  -I"$PROJECT_ROOT/replacement/bip" \
  -I"$PROJECT_ROOT/replacement/dip" \
  -I"$PROJECT_ROOT/replacement/tree_plru" \
  -I"$PROJECT_ROOT/replacement/lfu" \
  -I"$PROJECT_ROOT/replacement/ship_brrip" \
  "$PROJECT_ROOT/tests/policy_behavior_test.cc" \
  "$BUILD"/*.o -o "$BUILD/policy_behavior_test"

"$BUILD/policy_behavior_test"
python3 -m unittest "$PROJECT_ROOT/tests/test_parser.py"
python3 -m py_compile "$PROJECT_ROOT"/scripts/*.py
bash -n "$PROJECT_ROOT/scripts/run_all.sh"
bash -n "$PROJECT_ROOT/scripts/run_bonus_only_v2.sh"
python3 "$PROJECT_ROOT/scripts/generate_configs.py" \
  --policies lru,fifo,srrip,ship_brrip \
  --output-dir "$BUILD/generated_configs" >/dev/null

echo "all smoke tests passed"
