#ifndef TEST_CACHE_H
#define TEST_CACHE_H
#include <cstdint>
#include <type_traits>
namespace champsim {
namespace data::data_literals {
constexpr unsigned long long operator""_b(unsigned long long value) { return value; }
}
struct address {
  std::uint64_t value = 0;
  address() = default;
  address(std::uint64_t v) : value(v) {}
  template <auto Bits> address slice_lower() const {
    static_assert(Bits > 0 && Bits <= 64);
    if constexpr (Bits == 64)
      return *this;
    return address{value & ((std::uint64_t{1} << Bits) - 1)};
  }
  template <typename T> T to() const { return static_cast<T>(value); }
};
struct cache_block {};
}
enum class access_type : std::uint8_t { LOAD, RFO, PREFETCH, WRITE, TRANSLATION };
struct CACHE {
  long NUM_SET = 2048;
  long NUM_WAY = 16;
};
#endif
