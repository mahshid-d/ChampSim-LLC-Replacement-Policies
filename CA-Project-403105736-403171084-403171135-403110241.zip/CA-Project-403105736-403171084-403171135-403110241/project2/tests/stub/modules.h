#ifndef TEST_MODULES_H
#define TEST_MODULES_H
struct CACHE;
namespace champsim::modules {
struct replacement {
  explicit replacement(CACHE*) {}
};
}
#endif
