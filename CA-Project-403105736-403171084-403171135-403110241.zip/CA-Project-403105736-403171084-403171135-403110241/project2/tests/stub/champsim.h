#ifndef TEST_CHAMPSIM_H
#define TEST_CHAMPSIM_H
#include "cache.h"
#endif
