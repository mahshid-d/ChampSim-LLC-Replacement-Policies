# Final trace sources

Source collection: ChampSim SPEC CPU 2006 traces, Zenodo record 10959705.

| Logical name | Trace file | MD5 |
|---|---|---|
| h264ref_64B | `464.h264ref-64B.champsimtrace.xz` | `a6de8db734b9685487027c10c1a2d232` |
| zeusmp_10B | `434.zeusmp-10B.champsimtrace.xz` | `75d6872f86fec205b4aaf2a2aad5f3f4` |
| mcf_217B | `429.mcf-217B.champsimtrace.xz` | `7efef8e0a78e35f826f90fa8ab2b3992` |
| lbm_1274B | `470.lbm-1274B.champsimtrace.xz` | `ffff31ae0e6bbe57847863f28c5f7e4d` |

The trace archives are intentionally not included in the submission ZIP because of their size.
Before reproducing the experiments, copy the four files locally and edit the `path`
column in `manifest_final.csv`, or start from `manifest.example.csv`.
