# Trace files

The trace archives are intentionally not bundled because of their size.

Place these four files in this directory before reproducing the experiments:

- `464.h264ref-64B.champsimtrace.xz`
- `434.zeusmp-10B.champsimtrace.xz`
- `429.mcf-217B.champsimtrace.xz`
- `470.lbm-1274B.champsimtrace.xz`

Checksums and the download source are documented in `../TRACE_SOURCES.md`.
The final manifests use paths relative to the `traces/` directory.
