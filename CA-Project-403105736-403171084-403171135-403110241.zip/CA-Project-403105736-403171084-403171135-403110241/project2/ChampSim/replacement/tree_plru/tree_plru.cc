#include "tree_plru.h"

#include <cassert>

namespace {
bool is_power_of_two(long value)
{
  return value > 0 && (value & (value - 1)) == 0;
}
}

tree_plru::tree_plru(CACHE* cache)
    : replacement(cache), NUM_SET(cache->NUM_SET), NUM_WAY(cache->NUM_WAY),
      tree_bits(static_cast<std::size_t>(NUM_SET * ((NUM_WAY > 1) ? (NUM_WAY - 1) : 0)), 0)
{
  // A binary PLRU tree requires a power-of-two associativity. The assignment LLC is 16-way.
  assert(is_power_of_two(NUM_WAY));
}

std::size_t tree_plru::bit_index(long set, long node) const
{
  return static_cast<std::size_t>(set * (NUM_WAY - 1) + node);
}

long tree_plru::find_victim(std::uint32_t, std::uint64_t, long set, const champsim::cache_block*, champsim::address,
                            champsim::address, access_type)
{
  if (NUM_WAY == 1)
    return 0;

  long node = 0;
  long low = 0;
  long high = NUM_WAY;
  while (high - low > 1) {
    const auto direction = tree_bits.at(bit_index(set, node)); // 0: left subtree is LRU; 1: right subtree is LRU.
    const long mid = low + (high - low) / 2;
    if (direction == 0) {
      node = 2 * node + 1;
      high = mid;
    } else {
      node = 2 * node + 2;
      low = mid;
    }
  }
  return low;
}

void tree_plru::touch(long set, long way)
{
  if (NUM_WAY == 1)
    return;

  long node = 0;
  long low = 0;
  long high = NUM_WAY;
  while (high - low > 1) {
    const long mid = low + (high - low) / 2;
    if (way < mid) {
      tree_bits.at(bit_index(set, node)) = 1; // Accessed left; right becomes the LRU direction.
      node = 2 * node + 1;
      high = mid;
    } else {
      tree_bits.at(bit_index(set, node)) = 0; // Accessed right; left becomes the LRU direction.
      node = 2 * node + 2;
      low = mid;
    }
  }
}

void tree_plru::replacement_cache_fill(std::uint32_t, long set, long way, champsim::address, champsim::address,
                                       champsim::address, access_type)
{
  touch(set, way);
}

void tree_plru::update_replacement_state(std::uint32_t, long set, long way, champsim::address, champsim::address,
                                         champsim::address, access_type type, std::uint8_t hit)
{
  if (hit && type != access_type::WRITE)
    touch(set, way);
}
