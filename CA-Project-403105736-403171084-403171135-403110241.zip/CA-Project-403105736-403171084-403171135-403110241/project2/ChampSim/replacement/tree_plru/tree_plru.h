#ifndef REPLACEMENT_TREE_PLRU_H
#define REPLACEMENT_TREE_PLRU_H

#include <cstdint>
#include <vector>

#include "cache.h"
#include "modules.h"

class tree_plru : public champsim::modules::replacement
{
  long NUM_SET;
  long NUM_WAY;
  std::vector<std::uint8_t> tree_bits;

  std::size_t bit_index(long set, long node) const;
  void touch(long set, long way);

public:
  explicit tree_plru(CACHE* cache);

  long find_victim(std::uint32_t triggering_cpu, std::uint64_t instr_id, long set, const champsim::cache_block* current_set,
                   champsim::address ip, champsim::address full_addr, access_type type);

  void replacement_cache_fill(std::uint32_t triggering_cpu, long set, long way, champsim::address full_addr, champsim::address ip,
                              champsim::address victim_addr, access_type type);

  void update_replacement_state(std::uint32_t triggering_cpu, long set, long way, champsim::address full_addr, champsim::address ip,
                                champsim::address victim_addr, access_type type, std::uint8_t hit);
};

#endif
