#include "lfu.h"

#include <cassert>
#include <limits>

lfu::lfu(CACHE* cache)
    : replacement(cache), NUM_SET(cache->NUM_SET), NUM_WAY(cache->NUM_WAY),
      frequency(static_cast<std::size_t>(NUM_SET * NUM_WAY), 0),
      last_touch(static_cast<std::size_t>(NUM_SET * NUM_WAY), 0)
{
}

std::size_t lfu::index(long set, long way) const
{
  return static_cast<std::size_t>(set * NUM_WAY + way);
}

void lfu::decay_all()
{
  for (auto& value : frequency)
    value = static_cast<std::uint8_t>(value / 2);
}

void lfu::record_hit(long set, long way)
{
  auto& count = frequency.at(index(set, way));
  if (count == std::numeric_limits<std::uint8_t>::max())
    decay_all();
  count = static_cast<std::uint8_t>(count + 1);
  last_touch.at(index(set, way)) = sequence++;
}

long lfu::find_victim(std::uint32_t, std::uint64_t, long set, const champsim::cache_block*, champsim::address,
                      champsim::address, access_type)
{
  long victim = 0;
  for (long way = 1; way < NUM_WAY; ++way) {
    const auto candidate = index(set, way);
    const auto incumbent = index(set, victim);
    if (frequency.at(candidate) < frequency.at(incumbent) ||
        (frequency.at(candidate) == frequency.at(incumbent) && last_touch.at(candidate) < last_touch.at(incumbent)))
      victim = way;
  }
  return victim;
}

void lfu::replacement_cache_fill(std::uint32_t, long set, long way, champsim::address, champsim::address,
                                 champsim::address, access_type)
{
  assert(set >= 0 && set < NUM_SET);
  assert(way >= 0 && way < NUM_WAY);
  frequency.at(index(set, way)) = 1;
  last_touch.at(index(set, way)) = sequence++;
}

void lfu::update_replacement_state(std::uint32_t, long set, long way, champsim::address, champsim::address,
                                   champsim::address, access_type type, std::uint8_t hit)
{
  if (hit && type != access_type::WRITE)
    record_hit(set, way);
}
