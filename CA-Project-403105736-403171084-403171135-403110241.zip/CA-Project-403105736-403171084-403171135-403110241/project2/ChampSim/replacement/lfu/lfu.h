#ifndef REPLACEMENT_LFU_H
#define REPLACEMENT_LFU_H

#include <cstdint>
#include <vector>

#include "cache.h"
#include "modules.h"

class lfu : public champsim::modules::replacement
{
  long NUM_SET;
  long NUM_WAY;
  std::vector<std::uint8_t> frequency;
  std::vector<std::uint64_t> last_touch;
  std::uint64_t sequence = 1;

  std::size_t index(long set, long way) const;
  void decay_all();
  void record_hit(long set, long way);

public:
  explicit lfu(CACHE* cache);

  long find_victim(std::uint32_t triggering_cpu, std::uint64_t instr_id, long set, const champsim::cache_block* current_set,
                   champsim::address ip, champsim::address full_addr, access_type type);

  void replacement_cache_fill(std::uint32_t triggering_cpu, long set, long way, champsim::address full_addr, champsim::address ip,
                              champsim::address victim_addr, access_type type);

  void update_replacement_state(std::uint32_t triggering_cpu, long set, long way, champsim::address full_addr, champsim::address ip,
                                champsim::address victim_addr, access_type type, std::uint8_t hit);
};

#endif
