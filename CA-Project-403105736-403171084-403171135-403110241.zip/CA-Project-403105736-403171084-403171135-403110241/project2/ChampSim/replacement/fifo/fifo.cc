#include "fifo.h"

#include <algorithm>
#include <cassert>
#include <iterator>

fifo::fifo(CACHE* cache)
    : replacement(cache), NUM_SET(cache->NUM_SET), NUM_WAY(cache->NUM_WAY),
      insertion_order(static_cast<std::size_t>(NUM_SET * NUM_WAY), 0)
{
}

long fifo::find_victim(std::uint32_t, std::uint64_t, long set, const champsim::cache_block*, champsim::address,
                       champsim::address, access_type)
{
  auto begin = std::next(insertion_order.begin(), set * NUM_WAY);
  auto end = std::next(begin, NUM_WAY);
  const auto victim = std::min_element(begin, end);
  assert(victim != end);
  return std::distance(begin, victim);
}

void fifo::replacement_cache_fill(std::uint32_t, long set, long way, champsim::address, champsim::address,
                                  champsim::address, access_type)
{
  assert(set >= 0 && set < NUM_SET);
  assert(way >= 0 && way < NUM_WAY);
  insertion_order.at(static_cast<std::size_t>(set * NUM_WAY + way)) = sequence++;
}

void fifo::update_replacement_state(std::uint32_t, long, long, champsim::address, champsim::address,
                                    champsim::address, access_type, std::uint8_t)
{
  // FIFO deliberately ignores hits. State changes only when a line is inserted.
}
