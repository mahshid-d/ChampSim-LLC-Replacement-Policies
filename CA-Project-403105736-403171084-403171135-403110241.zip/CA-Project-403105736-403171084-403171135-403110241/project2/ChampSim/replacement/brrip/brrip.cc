#include "brrip.h"

#include <algorithm>
#include <cassert>
#include <iterator>

brrip::brrip(CACHE* cache)
    : replacement(cache), NUM_SET(cache->NUM_SET), NUM_WAY(cache->NUM_WAY),
      rrpv(static_cast<std::size_t>(NUM_SET * NUM_WAY), MAX_RRPV)
{
}

unsigned& brrip::value(long set, long way)
{
  return rrpv.at(static_cast<std::size_t>(set * NUM_WAY + way));
}

long brrip::find_victim(std::uint32_t, std::uint64_t, long set, const champsim::cache_block*, champsim::address,
                        champsim::address, access_type)
{
  auto begin = std::next(rrpv.begin(), set * NUM_WAY);
  auto end = std::next(begin, NUM_WAY);
  auto victim = std::max_element(begin, end);

  const auto delta = MAX_RRPV - *victim;
  if (delta != 0)
    for (auto it = begin; it != end; ++it)
      *it += delta;

  assert(victim != end);
  return std::distance(begin, victim);
}

void brrip::replacement_cache_fill(std::uint32_t, long set, long way, champsim::address, champsim::address,
                                   champsim::address, access_type type)
{
  if (type == access_type::WRITE) {
    value(set, way) = MAX_RRPV - 1;
    return;
  }

  ++insertion_counter;
  value(set, way) = (insertion_counter % LONG_INSERTION_PERIOD == 0) ? (MAX_RRPV - 1) : MAX_RRPV;
}

void brrip::update_replacement_state(std::uint32_t, long set, long way, champsim::address, champsim::address,
                                     champsim::address, access_type type, std::uint8_t hit)
{
  if (hit && type != access_type::WRITE)
    value(set, way) = 0;
}
