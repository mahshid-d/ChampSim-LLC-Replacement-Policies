#ifndef REPLACEMENT_SHIP_BRRIP_H
#define REPLACEMENT_SHIP_BRRIP_H

#include <cstddef>
#include <cstdint>
#include <vector>

#include "cache.h"
#include "modules.h"

// Bonus hybrid policy: a lightweight SHiP-style signature predictor chooses
// between SRRIP-like and BRRIP-like insertion. Hits always promote to RRPV=0.
class ship_brrip : public champsim::modules::replacement
{
  static constexpr std::uint8_t MAX_RRPV = 3;
  static constexpr std::size_t SHCT_SIZE = 4096;
  static constexpr std::uint8_t SHCT_MAX = 7;
  static constexpr std::uint8_t SHCT_THRESHOLD = 4;
  static constexpr unsigned LONG_INSERTION_PERIOD = 32;

  long NUM_SET;
  long NUM_WAY;
  std::vector<std::uint8_t> rrpv;
  std::vector<std::uint16_t> signatures;
  std::vector<std::uint8_t> reused;
  std::vector<std::uint8_t> valid;
  std::vector<std::uint8_t> shct;
  unsigned insertion_counter = 0;

  std::size_t line_index(long set, long way) const;
  std::size_t signature_of(champsim::address ip) const;
  void train_evicted_line(std::size_t index);

public:
  explicit ship_brrip(CACHE* cache);

  long find_victim(std::uint32_t triggering_cpu, std::uint64_t instr_id, long set,
                   const champsim::cache_block* current_set, champsim::address ip,
                   champsim::address full_addr, access_type type);

  void replacement_cache_fill(std::uint32_t triggering_cpu, long set, long way,
                              champsim::address full_addr, champsim::address ip,
                              champsim::address victim_addr, access_type type);

  void update_replacement_state(std::uint32_t triggering_cpu, long set, long way,
                                champsim::address full_addr, champsim::address ip,
                                champsim::address victim_addr, access_type type,
                                std::uint8_t hit);
};

#endif
