#include "ship_brrip.h"

#include <algorithm>
#include <cassert>
#include <iterator>

#include "champsim.h"

ship_brrip::ship_brrip(CACHE* cache)
    : replacement(cache), NUM_SET(cache->NUM_SET), NUM_WAY(cache->NUM_WAY),
      rrpv(static_cast<std::size_t>(NUM_SET * NUM_WAY), MAX_RRPV),
      signatures(static_cast<std::size_t>(NUM_SET * NUM_WAY), 0),
      reused(static_cast<std::size_t>(NUM_SET * NUM_WAY), 0),
      valid(static_cast<std::size_t>(NUM_SET * NUM_WAY), 0),
      shct(SHCT_SIZE, SHCT_THRESHOLD)
{
}

std::size_t ship_brrip::line_index(long set, long way) const
{
  return static_cast<std::size_t>(set * NUM_WAY + way);
}

std::size_t ship_brrip::signature_of(champsim::address ip) const
{
  using namespace champsim::data::data_literals;
  return ip.slice_lower<32_b>().to<std::size_t>() & (SHCT_SIZE - 1);
}

void ship_brrip::train_evicted_line(std::size_t index)
{
  if (!valid.at(index))
    return;

  auto& counter = shct.at(signatures.at(index));
  if (reused.at(index)) {
    if (counter < SHCT_MAX)
      ++counter;
  } else if (counter > 0) {
    --counter;
  }
}

long ship_brrip::find_victim(std::uint32_t, std::uint64_t, long set,
                             const champsim::cache_block*, champsim::address,
                             champsim::address, access_type)
{
  auto begin = std::next(rrpv.begin(), set * NUM_WAY);
  auto end = std::next(begin, NUM_WAY);
  auto victim = std::max_element(begin, end);

  const auto delta = static_cast<std::uint8_t>(MAX_RRPV - *victim);
  if (delta != 0)
    for (auto it = begin; it != end; ++it)
      *it = static_cast<std::uint8_t>(*it + delta);

  assert(victim != end);
  return std::distance(begin, victim);
}

void ship_brrip::replacement_cache_fill(std::uint32_t, long set, long way,
                                        champsim::address, champsim::address ip,
                                        champsim::address, access_type type)
{
  const auto index = line_index(set, way);
  train_evicted_line(index);

  if (type == access_type::WRITE) {
    rrpv.at(index) = MAX_RRPV - 1;
    valid.at(index) = 0;
    reused.at(index) = 0;
    return;
  }

  const auto signature = signature_of(ip);
  const bool predicted_reuse = shct.at(signature) >= SHCT_THRESHOLD;
  ++insertion_counter;
  const bool rare_long_reuse_insertion = insertion_counter % LONG_INSERTION_PERIOD == 0;

  // Predicted-reuse lines use SRRIP insertion. Predicted-dead lines use
  // BRRIP insertion, with a deterministic 1-in-32 second-chance approximation.
  rrpv.at(index) = predicted_reuse || rare_long_reuse_insertion ? (MAX_RRPV - 1) : MAX_RRPV;
  signatures.at(index) = static_cast<std::uint16_t>(signature);
  reused.at(index) = 0;
  valid.at(index) = 1;
}

void ship_brrip::update_replacement_state(std::uint32_t, long set, long way,
                                          champsim::address, champsim::address,
                                          champsim::address, access_type type,
                                          std::uint8_t hit)
{
  if (!hit || type == access_type::WRITE)
    return;

  const auto index = line_index(set, way);
  rrpv.at(index) = 0;
  reused.at(index) = 1;
}
