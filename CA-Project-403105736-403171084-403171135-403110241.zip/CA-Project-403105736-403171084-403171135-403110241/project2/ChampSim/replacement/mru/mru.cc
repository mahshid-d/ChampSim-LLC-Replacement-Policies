#include "mru.h"

#include <algorithm>
#include <cassert>
#include <iterator>

mru::mru(CACHE* cache)
    : replacement(cache), NUM_SET(cache->NUM_SET), NUM_WAY(cache->NUM_WAY),
      last_touch(static_cast<std::size_t>(NUM_SET * NUM_WAY), 0)
{
}

long mru::find_victim(std::uint32_t, std::uint64_t, long set, const champsim::cache_block*, champsim::address,
                      champsim::address, access_type)
{
  auto begin = std::next(last_touch.begin(), set * NUM_WAY);
  auto end = std::next(begin, NUM_WAY);
  const auto victim = std::max_element(begin, end);
  assert(victim != end);
  return std::distance(begin, victim);
}

void mru::replacement_cache_fill(std::uint32_t, long set, long way, champsim::address, champsim::address,
                                 champsim::address, access_type)
{
  assert(set >= 0 && set < NUM_SET);
  assert(way >= 0 && way < NUM_WAY);
  last_touch.at(static_cast<std::size_t>(set * NUM_WAY + way)) = sequence++;
}

void mru::update_replacement_state(std::uint32_t, long set, long way, champsim::address, champsim::address,
                                   champsim::address, access_type type, std::uint8_t hit)
{
  if (hit && type != access_type::WRITE)
    last_touch.at(static_cast<std::size_t>(set * NUM_WAY + way)) = sequence++;
}
