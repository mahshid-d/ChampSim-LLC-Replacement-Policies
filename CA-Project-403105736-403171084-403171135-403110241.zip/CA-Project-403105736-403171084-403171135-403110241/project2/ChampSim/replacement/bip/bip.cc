#include "bip.h"

#include <algorithm>
#include <cassert>
#include <iterator>

bip::bip(CACHE* cache)
    : replacement(cache), NUM_SET(cache->NUM_SET), NUM_WAY(cache->NUM_WAY),
      rank(static_cast<std::size_t>(NUM_SET * NUM_WAY), 0)
{
  for (long set = 0; set < NUM_SET; ++set)
    for (long way = 0; way < NUM_WAY; ++way)
      position(set, way) = way;
}

long& bip::position(long set, long way)
{
  return rank.at(static_cast<std::size_t>(set * NUM_WAY + way));
}

void bip::move_to_rank(long set, long way, long new_rank)
{
  const long old_rank = position(set, way);
  if (new_rank == old_rank)
    return;

  for (long candidate = 0; candidate < NUM_WAY; ++candidate) {
    if (candidate == way)
      continue;
    auto& candidate_rank = position(set, candidate);
    if (new_rank < old_rank && candidate_rank >= new_rank && candidate_rank < old_rank)
      ++candidate_rank;
    else if (new_rank > old_rank && candidate_rank > old_rank && candidate_rank <= new_rank)
      --candidate_rank;
  }
  position(set, way) = new_rank;
}

long bip::find_victim(std::uint32_t, std::uint64_t, long set, const champsim::cache_block*, champsim::address,
                      champsim::address, access_type)
{
  auto begin = std::next(rank.begin(), set * NUM_WAY);
  auto end = std::next(begin, NUM_WAY);
  const auto victim = std::max_element(begin, end);
  assert(victim != end);
  return std::distance(begin, victim);
}

void bip::replacement_cache_fill(std::uint32_t, long set, long way, champsim::address, champsim::address,
                                 champsim::address, access_type type)
{
  ++insertion_counter;
  const bool insert_at_mru = type != access_type::WRITE && (insertion_counter % MRU_INSERTION_PERIOD == 0);
  move_to_rank(set, way, insert_at_mru ? 0 : (NUM_WAY - 1));
}

void bip::update_replacement_state(std::uint32_t, long set, long way, champsim::address, champsim::address,
                                   champsim::address, access_type type, std::uint8_t hit)
{
  if (hit && type != access_type::WRITE)
    move_to_rank(set, way, 0);
}
