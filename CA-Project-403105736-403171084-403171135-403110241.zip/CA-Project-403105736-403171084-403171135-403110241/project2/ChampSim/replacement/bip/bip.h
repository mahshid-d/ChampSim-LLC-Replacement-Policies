#ifndef REPLACEMENT_BIP_H
#define REPLACEMENT_BIP_H

#include <cstdint>
#include <vector>

#include "cache.h"
#include "modules.h"

class bip : public champsim::modules::replacement
{
  static constexpr unsigned MRU_INSERTION_PERIOD = 32;

  long NUM_SET;
  long NUM_WAY;
  std::vector<long> rank;
  unsigned insertion_counter = 0;

  long& position(long set, long way);
  void move_to_rank(long set, long way, long new_rank);

public:
  explicit bip(CACHE* cache);

  long find_victim(std::uint32_t triggering_cpu, std::uint64_t instr_id, long set, const champsim::cache_block* current_set,
                   champsim::address ip, champsim::address full_addr, access_type type);

  void replacement_cache_fill(std::uint32_t triggering_cpu, long set, long way, champsim::address full_addr, champsim::address ip,
                              champsim::address victim_addr, access_type type);

  void update_replacement_state(std::uint32_t triggering_cpu, long set, long way, champsim::address full_addr, champsim::address ip,
                                champsim::address victim_addr, access_type type, std::uint8_t hit);
};

#endif
