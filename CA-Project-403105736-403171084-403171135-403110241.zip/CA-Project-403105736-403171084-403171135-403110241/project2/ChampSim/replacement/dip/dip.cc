#include "dip.h"

#include <algorithm>
#include <cassert>
#include <iterator>


dip::dip(CACHE* cache)
    : replacement(cache), NUM_SET(cache->NUM_SET), NUM_WAY(cache->NUM_WAY),
      rank(static_cast<std::size_t>(NUM_SET * NUM_WAY), 0)
{
  for (long set = 0; set < NUM_SET; ++set)
    for (long way = 0; way < NUM_WAY; ++way)
      position(set, way) = way;
}

long& dip::position(long set, long way)
{
  return rank.at(static_cast<std::size_t>(set * NUM_WAY + way));
}

void dip::move_to_rank(long set, long way, long new_rank)
{
  const long old_rank = position(set, way);
  if (new_rank == old_rank)
    return;

  for (long candidate = 0; candidate < NUM_WAY; ++candidate) {
    if (candidate == way)
      continue;
    auto& candidate_rank = position(set, candidate);
    if (new_rank < old_rank && candidate_rank >= new_rank && candidate_rank < old_rank)
      ++candidate_rank;
    else if (new_rank > old_rank && candidate_rank > old_rank && candidate_rank <= new_rank)
      --candidate_rank;
  }
  position(set, way) = new_rank;
}

dip::set_role dip::role(long set) const
{
  // Two deterministic leader-set classes. With 2048 sets, each class samples 32 sets.
  const long span = (NUM_SET >= 64) ? 64 : std::max<long>(4, NUM_SET);
  const long selector = set % span;
  if (selector == 0)
    return set_role::lru_leader;
  if (selector == 1)
    return set_role::bip_leader;
  return set_role::follower;
}

bool dip::use_bip(long set) const
{
  const auto set_role = role(set);
  if (set_role == set_role::bip_leader)
    return true;
  if (set_role == set_role::lru_leader)
    return false;
  return psel >= PSEL_MID;
}

void dip::update_selector_on_miss(long set)
{
  const auto set_role = role(set);
  if (set_role == set_role::lru_leader && psel < PSEL_MAX)
    ++psel; // LRU missed: move followers toward BIP.
  else if (set_role == set_role::bip_leader && psel > 0)
    --psel; // BIP missed: move followers toward LRU.
}

long dip::find_victim(std::uint32_t, std::uint64_t, long set, const champsim::cache_block*, champsim::address,
                      champsim::address, access_type)
{
  auto begin = std::next(rank.begin(), set * NUM_WAY);
  auto end = std::next(begin, NUM_WAY);
  const auto victim = std::max_element(begin, end);
  assert(victim != end);
  return std::distance(begin, victim);
}

void dip::replacement_cache_fill(std::uint32_t, long set, long way, champsim::address, champsim::address,
                                 champsim::address, access_type type)
{
  const bool choose_bip = use_bip(set);
  ++insertion_counter;
  const bool rare_mru = insertion_counter % MRU_INSERTION_PERIOD == 0;
  const bool insert_at_mru = type != access_type::WRITE && (!choose_bip || rare_mru);
  move_to_rank(set, way, insert_at_mru ? 0 : (NUM_WAY - 1));
  update_selector_on_miss(set);
}

void dip::update_replacement_state(std::uint32_t, long set, long way, champsim::address, champsim::address,
                                   champsim::address, access_type type, std::uint8_t hit)
{
  if (hit && type != access_type::WRITE)
    move_to_rank(set, way, 0);
}
