#ifndef REPLACEMENT_DIP_H
#define REPLACEMENT_DIP_H

#include <cstdint>
#include <vector>

#include "cache.h"
#include "modules.h"

class dip : public champsim::modules::replacement
{
  static constexpr unsigned MRU_INSERTION_PERIOD = 32;
  static constexpr unsigned PSEL_BITS = 10;
  static constexpr unsigned PSEL_MAX = (1u << PSEL_BITS) - 1;
  static constexpr unsigned PSEL_MID = 1u << (PSEL_BITS - 1);

  enum class set_role { follower, lru_leader, bip_leader };

  long NUM_SET;
  long NUM_WAY;
  std::vector<long> rank;
  unsigned insertion_counter = 0;
  unsigned psel = PSEL_MID;

  long& position(long set, long way);
  void move_to_rank(long set, long way, long new_rank);
  set_role role(long set) const;
  bool use_bip(long set) const;
  void update_selector_on_miss(long set);

public:
  explicit dip(CACHE* cache);

  long find_victim(std::uint32_t triggering_cpu, std::uint64_t instr_id, long set, const champsim::cache_block* current_set,
                   champsim::address ip, champsim::address full_addr, access_type type);

  void replacement_cache_fill(std::uint32_t triggering_cpu, long set, long way, champsim::address full_addr, champsim::address ip,
                              champsim::address victim_addr, access_type type);

  void update_replacement_state(std::uint32_t triggering_cpu, long set, long way, champsim::address full_addr, champsim::address ip,
                                champsim::address victim_addr, access_type type, std::uint8_t hit);
};

#endif
