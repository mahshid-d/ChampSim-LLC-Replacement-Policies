# Reproducing the ChampSim environment

The submission contains a clean source snapshot and the custom replacement
modules. Third-party dependencies and the contents of the ChampSim `vcpkg`
submodule are not bundled to keep the submission size reasonable.

ChampSim commit used for the experiments:

```text
51588e1d6f97875fe8de1a3621d28668bff83fcf
```

Recommended clean setup:

```bash
git clone --recurse-submodules https://github.com/ChampSim/ChampSim.git
cd ChampSim
git checkout 51588e1d6f97875fe8de1a3621d28668bff83fcf
git submodule update --init --recursive
```

Then install the submitted policies:

```bash
python3 /path/to/project2/scripts/install_policies.py \
  --champsim-root "$PWD" \
  --force
```

Install Python dependencies in the project directory:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

Place the four traces under `traces/trace_files/`, then run:

```bash
PYTHON=.venv/bin/python make run CHAMPSIM_ROOT=/path/to/ChampSim
```

The pipeline uses `--resume`, so already complete raw outputs are not rerun.
